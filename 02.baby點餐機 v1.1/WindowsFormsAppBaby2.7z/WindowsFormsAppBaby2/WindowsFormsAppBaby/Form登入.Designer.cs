﻿namespace WindowsFormsAppBaby
{
    partial class Form登入
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form登入));
            this.label3 = new System.Windows.Forms.Label();
            this.cbox訂購人 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbox訂購單位 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl值日生 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt密碼 = new System.Windows.Forms.TextBox();
            this.txt系統訊息 = new System.Windows.Forms.TextBox();
            this.btn登入 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Red;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(-11, -3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(545, 47);
            this.label3.TabIndex = 6;
            this.label3.Text = "=== 吃貨系統 Menu ===";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbox訂購人
            // 
            this.cbox訂購人.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.cbox訂購人.FormattingEnabled = true;
            this.cbox訂購人.Location = new System.Drawing.Point(75, 97);
            this.cbox訂購人.Name = "cbox訂購人";
            this.cbox訂購人.Size = new System.Drawing.Size(182, 32);
            this.cbox訂購人.TabIndex = 25;
            this.cbox訂購人.SelectedIndexChanged += new System.EventHandler(this.cbox訂購人_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 24);
            this.label2.TabIndex = 24;
            this.label2.Text = "訂購人";
            // 
            // cbox訂購單位
            // 
            this.cbox訂購單位.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.cbox訂購單位.FormattingEnabled = true;
            this.cbox訂購單位.Location = new System.Drawing.Point(99, 59);
            this.cbox訂購單位.Name = "cbox訂購單位";
            this.cbox訂購單位.Size = new System.Drawing.Size(158, 32);
            this.cbox訂購單位.TabIndex = 23;
            this.cbox訂購單位.SelectedIndexChanged += new System.EventHandler(this.cbox訂購單位_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 24);
            this.label1.TabIndex = 22;
            this.label1.Text = "訂購單位";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(263, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 24);
            this.label4.TabIndex = 26;
            this.label4.Text = "值日生";
            // 
            // lbl值日生
            // 
            this.lbl值日生.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl值日生.Location = new System.Drawing.Point(336, 59);
            this.lbl值日生.Name = "lbl值日生";
            this.lbl值日生.Size = new System.Drawing.Size(183, 33);
            this.lbl值日生.TabIndex = 27;
            this.lbl值日生.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(263, 101);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 24);
            this.label5.TabIndex = 28;
            this.label5.Text = "密碼";
            // 
            // txt密碼
            // 
            this.txt密碼.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.txt密碼.Location = new System.Drawing.Point(317, 98);
            this.txt密碼.Name = "txt密碼";
            this.txt密碼.Size = new System.Drawing.Size(202, 33);
            this.txt密碼.TabIndex = 29;
            this.txt密碼.Text = "1234";
            this.txt密碼.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt密碼_KeyDown);
            // 
            // txt系統訊息
            // 
            this.txt系統訊息.Location = new System.Drawing.Point(11, 190);
            this.txt系統訊息.Multiline = true;
            this.txt系統訊息.Name = "txt系統訊息";
            this.txt系統訊息.ReadOnly = true;
            this.txt系統訊息.Size = new System.Drawing.Size(508, 59);
            this.txt系統訊息.TabIndex = 30;
            this.txt系統訊息.Text = "歡迎使用Baby吃貨系統";
            this.txt系統訊息.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt系統訊息.UseWaitCursor = true;
            // 
            // btn登入
            // 
            this.btn登入.BackColor = System.Drawing.Color.Red;
            this.btn登入.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn登入.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn登入.Location = new System.Drawing.Point(11, 135);
            this.btn登入.Name = "btn登入";
            this.btn登入.Size = new System.Drawing.Size(508, 49);
            this.btn登入.TabIndex = 31;
            this.btn登入.Text = "登入";
            this.btn登入.UseVisualStyleBackColor = false;
            this.btn登入.Click += new System.EventHandler(this.btn登入_Click);
            // 
            // Form登入
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(531, 263);
            this.Controls.Add(this.btn登入);
            this.Controls.Add(this.txt系統訊息);
            this.Controls.Add(this.txt密碼);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lbl值日生);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbox訂購人);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbox訂購單位);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form登入";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Baby點餐機 v1.1";
            this.Load += new System.EventHandler(this.Form登入_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbox訂購人;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbox訂購單位;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl值日生;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt密碼;
        private System.Windows.Forms.TextBox txt系統訊息;
        private System.Windows.Forms.Button btn登入;
    }
}