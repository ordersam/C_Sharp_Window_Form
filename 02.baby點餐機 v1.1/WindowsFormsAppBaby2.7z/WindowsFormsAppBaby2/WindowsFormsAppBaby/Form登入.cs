﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsAppBaby.Entity;
using WindowsFormsAppBaby.Factory;

namespace WindowsFormsAppBaby
{
    public partial class Form登入 : Form
    {
        // ============== 訂購單位 ==============
        List<c訂購單位> listOrg = new List<c訂購單位>();
        // 目前訂購單位
        c訂購單位 OrgNow;
        public void read讀取訂購單位()
        {
            // 加入內存
            listOrg = (new c訂購單位Factory()).queryAll訂購單位();
            
            if (listOrg != null)
            {
                // 顯示在UI
                foreach (c訂購單位 item in listOrg)
                {
                    cbox訂購單位.Items.Add(item.f訂購單位);
                }
                // 記錄在Glabal
                GlobalVar.listGlobalOrg = listOrg;
            }
        }

        // ============== 訂購人 ==============
        List<c訂購人> listPerson = new List<c訂購人>();
        // 值日生
        c訂購人 Person值日生;
        // 目前訂購人
        c訂購人 PersonNow;
        // 指定訂購單位id 列出訂購人(預設第一個)+單位值日生
        public void read讀取訂購人(int fId)
        {
            // 加入內存
            listPerson = (new c訂購人Factory()).query單位訂購人(fId);

            if (listPerson != null)
            {
                // 顯示在UI
                cbox訂購人.Items.Clear();
                foreach (c訂購人 item in listPerson)
                {
                    cbox訂購人.Items.Add($"{item.f姓名}[{item.fId}]");
                }

                // ========== 預設第一個訂購人 ==========
                cbox訂購人.SelectedIndex = 0;
                PersonNow = listPerson[cbox訂購人.SelectedIndex];

                // ========== 值日生 ==========
                Person值日生 = (new c訂購人Factory()).query單位值日生(fId);
                if (Person值日生 != null)
                {
                    lbl值日生.Text = $"{Person值日生.f姓名}[{Person值日生.fId}]";
                }
            }
        }

        public Form登入()
        {
            InitializeComponent();
        }

        private void Form登入_Load(object sender, EventArgs e)
        {
            // 內存初始化
            listOrg.Clear();
            OrgNow = null;
            listPerson.Clear();
            Person值日生 = null;
            PersonNow = null;
            // UI初始化
            cbox訂購單位.Items.Clear();
            cbox訂購人.Items.Clear();
            lbl值日生.Text = "";
            txt密碼.Text = "";
            txt系統訊息.Text = "歡迎使用Baby吃貨系統";

            // ============== 訂購單位 內存 + UI + Global + 預設第一個 ==============
            read讀取訂購單位();
            if (listOrg != null)
            {
                cbox訂購單位.SelectedIndex = 0;
                OrgNow = listOrg[cbox訂購單位.SelectedIndex];
                // ======= 預設第一個訂購單位 對應的訂購人選單+預設第一個訂購人 =======
                read讀取訂購人(OrgNow.fId);
            }
        }

        private void cbox訂購單位_SelectedIndexChanged(object sender, EventArgs e)
        {
            OrgNow = listOrg[cbox訂購單位.SelectedIndex];
            // =========== 對應的訂購人 ===========
            read讀取訂購人(OrgNow.fId);
        }

        private void cbox訂購人_SelectedIndexChanged(object sender, EventArgs e)
        {
            PersonNow = listPerson[cbox訂購人.SelectedIndex];
        }

        private void btn登入_Click(object sender, EventArgs e)
        {
            if (PersonNow != null)
            {
                // 比對密碼
                if (txt密碼.Text == PersonNow.f密碼)
                {
                    GlobalOrder.e目前訂購單位 = OrgNow;
                    GlobalOrder.e目前訂購人 = PersonNow;
                    // 關閉form
                    this.Close();
                }
                else
                {
                    txt系統訊息.Text = "密碼錯誤！";
                }
            }
            else
            {
                txt系統訊息.Text = "尚未選取訂購人！";
            }
        }

        // txt密碼 按下Enter
        private void txt密碼_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // 聚焦到按鈕
                btn登入.Focus();
                // 按下按鈕
                btn登入_Click(sender, e);
                // 聚焦回來
                txt密碼.Focus();

            }
        }
    }
}
