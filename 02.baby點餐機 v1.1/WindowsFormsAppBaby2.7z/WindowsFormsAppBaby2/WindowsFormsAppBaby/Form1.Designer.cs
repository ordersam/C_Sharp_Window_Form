﻿namespace WindowsFormsAppBaby
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.listView1 = new System.Windows.Forms.ListView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.pbox餐點圖 = new System.Windows.Forms.PictureBox();
            this.pbox查看訂購單 = new System.Windows.Forms.PictureBox();
            this.pbox加入訂購單 = new System.Windows.Forms.PictureBox();
            this.pbox登出 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lbox菜單 = new System.Windows.Forms.ListBox();
            this.cbox餐廳 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.nud數量 = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txt單價 = new System.Windows.Forms.TextBox();
            this.txt小計 = new System.Windows.Forms.TextBox();
            this.txt系統訊息 = new System.Windows.Forms.TextBox();
            this.txt訂購單位 = new System.Windows.Forms.TextBox();
            this.txt訂購人 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbox餐點圖)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox查看訂購單)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox加入訂購單)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox登出)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud數量)).BeginInit();
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.Color.MistyRose;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(16, 110);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(142, 452);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.ItemActivate += new System.EventHandler(this.listView1_ItemActivate);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "訂購單位";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(238, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 24);
            this.label2.TabIndex = 3;
            this.label2.Text = "訂購人";
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(256, 256);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Red;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(-3, 1);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(485, 47);
            this.label3.TabIndex = 5;
            this.label3.Text = "=== 吃貨系統 Menu ===";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbox餐點圖
            // 
            this.pbox餐點圖.Image = global::WindowsFormsAppBaby.Properties.Resources._default;
            this.pbox餐點圖.Location = new System.Drawing.Point(168, 374);
            this.pbox餐點圖.Name = "pbox餐點圖";
            this.pbox餐點圖.Size = new System.Drawing.Size(124, 122);
            this.pbox餐點圖.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox餐點圖.TabIndex = 10;
            this.pbox餐點圖.TabStop = false;
            // 
            // pbox查看訂購單
            // 
            this.pbox查看訂購單.BackColor = System.Drawing.Color.Red;
            this.pbox查看訂購單.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbox查看訂購單.Image = global::WindowsFormsAppBaby.Properties.Resources.bill2;
            this.pbox查看訂購單.Location = new System.Drawing.Point(429, 5);
            this.pbox查看訂購單.Name = "pbox查看訂購單";
            this.pbox查看訂購單.Size = new System.Drawing.Size(45, 40);
            this.pbox查看訂購單.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox查看訂購單.TabIndex = 9;
            this.pbox查看訂購單.TabStop = false;
            this.pbox查看訂購單.Click += new System.EventHandler(this.pbox查看訂購單_Click);
            // 
            // pbox加入訂購單
            // 
            this.pbox加入訂購單.BackColor = System.Drawing.Color.Red;
            this.pbox加入訂購單.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbox加入訂購單.Image = global::WindowsFormsAppBaby.Properties.Resources.cart1;
            this.pbox加入訂購單.Location = new System.Drawing.Point(383, 5);
            this.pbox加入訂購單.Name = "pbox加入訂購單";
            this.pbox加入訂購單.Size = new System.Drawing.Size(45, 40);
            this.pbox加入訂購單.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox加入訂購單.TabIndex = 8;
            this.pbox加入訂購單.TabStop = false;
            this.pbox加入訂購單.Click += new System.EventHandler(this.pbox加入訂購單_Click);
            // 
            // pbox登出
            // 
            this.pbox登出.BackColor = System.Drawing.Color.Red;
            this.pbox登出.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbox登出.Image = global::WindowsFormsAppBaby.Properties.Resources.login;
            this.pbox登出.Location = new System.Drawing.Point(-7, 1);
            this.pbox登出.Name = "pbox登出";
            this.pbox登出.Size = new System.Drawing.Size(48, 46);
            this.pbox登出.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox登出.TabIndex = 7;
            this.pbox登出.TabStop = false;
            this.pbox登出.Click += new System.EventHandler(this.pbox登出_Click);
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(164, 110);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 32);
            this.label4.TabIndex = 11;
            this.label4.Text = "餐廳";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbox菜單
            // 
            this.lbox菜單.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbox菜單.FormattingEnabled = true;
            this.lbox菜單.ItemHeight = 24;
            this.lbox菜單.Location = new System.Drawing.Point(168, 148);
            this.lbox菜單.Name = "lbox菜單";
            this.lbox菜單.Size = new System.Drawing.Size(295, 220);
            this.lbox菜單.TabIndex = 12;
            this.lbox菜單.SelectedIndexChanged += new System.EventHandler(this.lbox菜單_SelectedIndexChanged);
            // 
            // cbox餐廳
            // 
            this.cbox餐廳.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.cbox餐廳.ForeColor = System.Drawing.Color.Maroon;
            this.cbox餐廳.FormattingEnabled = true;
            this.cbox餐廳.Location = new System.Drawing.Point(228, 110);
            this.cbox餐廳.Name = "cbox餐廳";
            this.cbox餐廳.Size = new System.Drawing.Size(235, 32);
            this.cbox餐廳.TabIndex = 13;
            this.cbox餐廳.Text = "請先點選左方餵食種類";
            this.cbox餐廳.SelectedIndexChanged += new System.EventHandler(this.cbox餐廳_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(298, 383);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 24);
            this.label5.TabIndex = 14;
            this.label5.Text = "數量";
            // 
            // nud數量
            // 
            this.nud數量.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.nud數量.Location = new System.Drawing.Point(352, 374);
            this.nud數量.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud數量.Name = "nud數量";
            this.nud數量.Size = new System.Drawing.Size(111, 33);
            this.nud數量.TabIndex = 15;
            this.nud數量.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud數量.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud數量.ValueChanged += new System.EventHandler(this.nud數量_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(298, 422);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 24);
            this.label6.TabIndex = 16;
            this.label6.Text = "單價";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(298, 461);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 24);
            this.label7.TabIndex = 17;
            this.label7.Text = "小計";
            // 
            // txt單價
            // 
            this.txt單價.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.txt單價.Location = new System.Drawing.Point(352, 413);
            this.txt單價.Name = "txt單價";
            this.txt單價.ReadOnly = true;
            this.txt單價.Size = new System.Drawing.Size(111, 33);
            this.txt單價.TabIndex = 18;
            this.txt單價.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt小計
            // 
            this.txt小計.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.txt小計.Location = new System.Drawing.Point(352, 452);
            this.txt小計.Name = "txt小計";
            this.txt小計.ReadOnly = true;
            this.txt小計.Size = new System.Drawing.Size(111, 33);
            this.txt小計.TabIndex = 19;
            this.txt小計.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt系統訊息
            // 
            this.txt系統訊息.Location = new System.Drawing.Point(168, 503);
            this.txt系統訊息.Multiline = true;
            this.txt系統訊息.Name = "txt系統訊息";
            this.txt系統訊息.ReadOnly = true;
            this.txt系統訊息.Size = new System.Drawing.Size(295, 59);
            this.txt系統訊息.TabIndex = 20;
            this.txt系統訊息.Text = "歡迎使用Baby吃貨系統";
            this.txt系統訊息.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt系統訊息.UseWaitCursor = true;
            // 
            // txt訂購單位
            // 
            this.txt訂購單位.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.txt訂購單位.Location = new System.Drawing.Point(104, 61);
            this.txt訂購單位.Name = "txt訂購單位";
            this.txt訂購單位.ReadOnly = true;
            this.txt訂購單位.Size = new System.Drawing.Size(128, 33);
            this.txt訂購單位.TabIndex = 21;
            this.txt訂購單位.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt訂購人
            // 
            this.txt訂購人.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.txt訂購人.Location = new System.Drawing.Point(302, 61);
            this.txt訂購人.Name = "txt訂購人";
            this.txt訂購人.ReadOnly = true;
            this.txt訂購人.Size = new System.Drawing.Size(161, 33);
            this.txt訂購人.TabIndex = 22;
            this.txt訂購人.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(478, 571);
            this.Controls.Add(this.txt訂購人);
            this.Controls.Add(this.txt訂購單位);
            this.Controls.Add(this.txt系統訊息);
            this.Controls.Add(this.txt小計);
            this.Controls.Add(this.txt單價);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.nud數量);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cbox餐廳);
            this.Controls.Add(this.lbox菜單);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pbox餐點圖);
            this.Controls.Add(this.pbox查看訂購單);
            this.Controls.Add(this.pbox加入訂購單);
            this.Controls.Add(this.pbox登出);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listView1);
            this.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Baby點餐機 v1.1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbox餐點圖)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox查看訂購單)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox加入訂購單)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox登出)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud數量)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pbox登出;
        private System.Windows.Forms.PictureBox pbox加入訂購單;
        private System.Windows.Forms.PictureBox pbox查看訂購單;
        private System.Windows.Forms.PictureBox pbox餐點圖;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox lbox菜單;
        private System.Windows.Forms.ComboBox cbox餐廳;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown nud數量;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt單價;
        private System.Windows.Forms.TextBox txt小計;
        private System.Windows.Forms.TextBox txt系統訊息;
        private System.Windows.Forms.TextBox txt訂購單位;
        private System.Windows.Forms.TextBox txt訂購人;
    }
}

