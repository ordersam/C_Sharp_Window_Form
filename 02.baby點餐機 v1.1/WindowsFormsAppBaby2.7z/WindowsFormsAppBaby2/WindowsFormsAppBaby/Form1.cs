﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsAppBaby.Entity;
using WindowsFormsAppBaby.Factory;

namespace WindowsFormsAppBaby
{
    public partial class Form1 : Form
    {
        // =============== 點餐分類：內存 + UI ===============
        List<c點餐分類> list點餐分類;
        // user選取分類
        c點餐分類 class目前分類;
        void listview顯示點餐分類()
        {
            // 加入內存
            list點餐分類 = (new c點餐分類Factory()).queryAll點餐分類();

            if (list點餐分類 != null)
            {
                // 顯示在UI
                // 圖檔加入imageList1
                imageList1.Images.Clear();
                string str圖檔路徑 = @"category/";
                foreach (c點餐分類 item in list點餐分類)
                {
                    imageList1.Images.Add(Image.FromFile(str圖檔路徑 + item.f圖片));
                }
                // 設定ListView
                listView1.Clear();
                listView1.View = View.LargeIcon;
                imageList1.ImageSize = new Size(95, 95);
                listView1.LargeImageList = imageList1;
                for (int i = 0; i < imageList1.Images.Count; i++)
                {
                    ListViewItem item = new ListViewItem();
                    item.ImageIndex = i;
                    item.Font = new Font("微軟正黑體", 14, FontStyle.Bold);
                    item.Text = list點餐分類[i].f分類;
                    listView1.Items.Add(item);
                }
            }
        }

        // =============== 餐廳、餐點：內存 + UI ===============
        // 目前點餐分類 對應的 餐廳
        List<c餐廳> list分類對應餐廳;
        // user選取餐廳
        c餐廳 class目前餐廳;

        // 目前點餐分類 + 目前餐廳 對應的餐點
        List<c餐點> list分類餐廳對應餐點;
        // user選取餐點
        c餐點 class目前餐點;

        // 目前點餐分類 對應的 餐廳 (參數 分類fId)
        void read對應餐廳(int fId)
        {
            // 加入內存
            list分類對應餐廳 = (new c餐廳Factory()).queryBy點餐分類(fId);

            if (list分類對應餐廳 != null)
            {
                // 顯示在UI
                cbox餐廳.Items.Clear();
                foreach (c餐廳 item in list分類對應餐廳)
                {
                    cbox餐廳.Items.Add(item.f餐廳名稱);
                }

                // 預設值
                cbox餐廳.SelectedIndex = 0;
                class目前餐廳 = list分類對應餐廳[cbox餐廳.SelectedIndex];

                // 對應餐點
                read分類餐廳對應餐點(fId, class目前餐廳.fId);
            }
        }

        // 目前點餐分類+餐廳 對應的餐點
        void read分類餐廳對應餐點(int f分類Id, int f餐廳Id)
        {
            // 加入內存
            list分類餐廳對應餐點 = (new c餐點Factory()).queryBy點餐分類(f分類Id, f餐廳Id);

            if (list分類餐廳對應餐點 != null)
            {
                // 顯示在UI
                lbox菜單.Items.Clear();
                foreach (c餐點 item in list分類餐廳對應餐點)
                {
                    lbox菜單.Items.Add(item.f餐點);
                }
                // 注意沒有預設值，user需要點選餐點 class目前餐點才有值
            }
        }

        // =============== 其他內存 ===============
        // user選取數量
        int int數量;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // =========== 登入 ===========
            if ((GlobalOrder.e目前訂購單位 == null) || (GlobalOrder.e目前訂購人 == null))
            {
                Form form登入 = new Form登入();
                form登入.ShowDialog();
            }
            // 顯示訂購單位、訂購人
            txt訂購單位.Text = GlobalOrder.e目前訂購單位.f訂購單位;
            txt訂購人.Text = $"{GlobalOrder.e目前訂購人.f姓名} [{GlobalOrder.e目前訂購人.fId}]";

            // 內存初始化
            list點餐分類 = null;
            class目前分類 = null;
            list分類對應餐廳 = null;
            class目前餐廳 = null;
            list分類餐廳對應餐點 = null;
            class目前餐點 = null;
            int數量 = 1;
            // UI初始化
            cbox餐廳.Text = "請先點選左方餵食種類";
            cbox餐廳.Items.Clear();
            lbox菜單.Items.Clear();
            nud數量.Value = 1;
            txt單價.Text = "";
            txt小計.Text = "";
            txt系統訊息.Text = "歡迎使用Baby吃貨系統";

            // 顯示點餐分類
            listview顯示點餐分類();
        }

        // ======================= Event =======================
        // 點選點餐分類
        private void listView1_ItemActivate(object sender, EventArgs e)
        {
            // 內存初始化
            list分類對應餐廳 = null;
            class目前餐廳 = null;
            list分類餐廳對應餐點 = null;
            class目前餐點 = null;
            int數量 = 1;
            // UI初始化
            cbox餐廳.Items.Clear();
            lbox菜單.Items.Clear();
            nud數量.Value = 1;
            txt單價.Text = "";
            txt小計.Text = "";
            txt系統訊息.Text = "歡迎使用Baby吃貨系統";

            // user點選分類
            class目前分類 = list點餐分類[listView1.SelectedIndices[0]];
            // 對應目前餐廳
            read對應餐廳(class目前分類.fId);
        }

        // 點選餐廳
        private void cbox餐廳_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 內存初始化
            list分類餐廳對應餐點 = null;
            class目前餐點 = null;
            int數量 = 1;
            // UI初始化
            lbox菜單.Items.Clear();
            nud數量.Value = 1;
            txt單價.Text = "";
            txt小計.Text = "";
            txt系統訊息.Text = "歡迎使用Baby吃貨系統";

            // user點選餐廳
            class目前餐廳 = list分類對應餐廳[cbox餐廳.SelectedIndex];
            // 對應目前餐點
            read分類餐廳對應餐點(class目前分類.fId, class目前餐廳.fId);
        }

        // 點選餐點
        private void lbox菜單_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 內存初始化
            int數量 = 1;
            // UI初始化
            nud數量.Value = 1;
            txt系統訊息.Text = "歡迎使用Baby吃貨系統";

            // user點選餐點
            class目前餐點 = list分類餐廳對應餐點[lbox菜單.SelectedIndex];

            // UI
            txt單價.Text = class目前餐點.f價格.ToString();
            // 如果打不開用預設圖片
            try
            {
                pbox餐點圖.Image = Image.FromFile(@"menu/" + class目前餐點.f圖片);
            }
            catch
            {
                pbox餐點圖.Image = Image.FromFile(@"menu/default.png");
            }
            // 計算總價 顯示UI
            total計算總價(class目前餐點.f價格, int數量);
        }

        // 點選數量
        private void nud數量_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                int數量 = Convert.ToInt32(nud數量.Value);
                if (class目前餐點 != null)
                {
                    total計算總價(class目前餐點.f價格, int數量);
                }
                txt系統訊息.Text = "歡迎使用Baby吃貨系統";
            }
            catch
            {
                int數量 = 1;
                nud數量.Value = 1;
                txt系統訊息.Text = "數量輸入錯誤 請不要亂玩>w<";
            }
        }

        // 計算總價 顯示UI
        int total計算總價(int int單價, int int數量)
        {
            txt小計.Text = (int單價 * int數量).ToString();
            return int單價 * int數量;
        }

        // ======================= Navigator =======================
        private void pbox加入訂購單_Click(object sender, EventArgs e)
        {
            if (class目前餐點 != null)
            {
                c訂單明細 x = new c訂單明細();
                x.f訂購人Id = GlobalOrder.e目前訂購人.fId;
                x.f餐點Id = class目前餐點.fId;
                x.f數量 = int數量;
                x.a單位Id = GlobalOrder.e目前訂購單位.fId;
                x.a餐廳Id = class目前餐點.f餐廳Id;
                GlobalOrder.list訂單明細.Add(x);
                txt系統訊息.Text = "訂購成功 開啟吃貨之路！";
            }
            else
            {
                txt系統訊息.Text = "訂購失敗 請選擇餐點！";
            }
        }

        private void pbox查看訂購單_Click(object sender, EventArgs e)
        {
            Form form訂單列表 = new Form2();
            form訂單列表.ShowDialog();
        }

        // ===================== logout切換身分 =====================
        private void pbox登出_Click(object sender, EventArgs e)
        {
            GlobalOrder.e目前訂購單位 = null;
            GlobalOrder.e目前訂購人 = null;

            Form form登入 = new Form登入();
            form登入.ShowDialog();

            // 顯示訂購單位、訂購人
            txt訂購單位.Text = GlobalOrder.e目前訂購單位.f訂購單位;
            txt訂購人.Text = $"{GlobalOrder.e目前訂購人.f姓名} [{GlobalOrder.e目前訂購人.fId}]";

            // 內存初始化
            list點餐分類 = null;
            class目前分類 = null;
            list分類對應餐廳 = null;
            class目前餐廳 = null;
            list分類餐廳對應餐點 = null;
            class目前餐點 = null;
            int數量 = 1;
            // UI初始化
            cbox餐廳.Text = "請先點選左方餵食種類";
            cbox餐廳.Items.Clear();
            lbox菜單.Items.Clear();
            nud數量.Value = 1;
            txt單價.Text = "";
            txt小計.Text = "";
            txt系統訊息.Text = "歡迎使用Baby吃貨系統";

            // 顯示點餐分類
            listview顯示點餐分類();
        }
    }
}
