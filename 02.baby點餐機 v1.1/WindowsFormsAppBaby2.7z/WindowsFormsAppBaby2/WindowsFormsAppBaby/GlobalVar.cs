﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsAppBaby.Entity;
using WindowsFormsAppBaby.Factory;

namespace WindowsFormsAppBaby
{
    class GlobalVar
    {
        public static string sqlstring = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\dbBabyLocal.mdf;Integrated Security=True";

        // 所有訂購單位
        public static List<c訂購單位> listGlobalOrg = new List<c訂購單位>();
    }
}
