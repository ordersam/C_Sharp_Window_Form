﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsAppBaby.Entity;
using WindowsFormsAppBaby.Factory;

namespace WindowsFormsAppBaby
{
    class GlobalOrder
    {
        // 目前登入訂購單位
        public static c訂購單位 e目前訂購單位;
        // 目前登入訂購人
        public static c訂購人 e目前訂購人;

        // 訂購單
        public static List<c訂單明細> list訂單明細 = new List<c訂單明細>();
    }
}
