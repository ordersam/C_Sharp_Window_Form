﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsAppBaby.Entity;
using WindowsFormsAppBaby.Factory;

namespace WindowsFormsAppBaby
{
    public partial class Form2 : Form
    {
        // ================ 內存 ================
        bool is管理員;
        // 非管理員 部分權限使用(不用在搜尋)
        List<c訂單明細> list訂單明細Now = new List<c訂單明細>();
        // 搜尋使用
        bool is搜訂購;
        bool is搜餐廳;
        List<c訂購單位> list所有訂購單位 = new List<c訂購單位>();
        List<c訂購人> list目前單位訂購人 = new List<c訂購人>();
        List<c餐廳> list所有餐廳 = new List<c餐廳>();
        List<c訂單明細> list搜尋訂單明細 = new List<c訂單明細>();
        int int搜尋訂購單位Id;
        int int搜尋訂購人Id;
        int int搜尋餐廳Id;

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            if (GlobalOrder.e目前訂購人.fId == 0)
                is管理員 = true;
            else
                is管理員 = false;

            // 身分識別(系統管理者可以檢視刪除全部、值日生只能檢視刪除自己單位)
            reset訂單列表(GlobalOrder.e目前訂購人.f值日生權限);
        }

        int total計算總價(List<c訂單明細> list訂單明細)
        {
            int int總價 = 0;
            if (list訂單明細.Count > 0)
            {
                foreach (c訂單明細 item in list訂單明細)
                {
                    c餐點 c餐 = (new c餐點Factory()).queryById(item.f餐點Id);
                    int總價 += item.f數量 * c餐.f價格;
                }
                lbl總計.Text = int總價.ToString() + " 元";
            }
            else
            {
                lbl總計.Text = "";
            }
            return int總價;
        }

        // 依照權限顯示總表(未篩選)
        void reset訂單列表(bool is有值日生權限)
        {
            // 內存初始化
            list訂單明細Now.Clear();
            is搜訂購 = false;
            is搜餐廳 = false;
            list所有訂購單位.Clear();
            list目前單位訂購人.Clear();
            list所有餐廳.Clear();
            list搜尋訂單明細.Clear();
            int搜尋訂購單位Id = -1;
            int搜尋訂購人Id = -1;
            int搜尋餐廳Id = -1;
            // UI初始化
            lbox訂單列表.Items.Clear();
            lbl總計.Text = "";
            cbox訂購單位.Items.Clear();
            cbox訂購人.Items.Clear();
            cbox餐廳.Items.Clear();
            cbox訂購單位.Text = "";
            cbox訂購人.Text = "";
            cbox餐廳.Text = "";
            cbox訂購單位.Enabled = true;
            cbox訂購人.Enabled = true;
            cbox餐廳.Enabled = true;
            btn餐廳排序.Enabled = true;

            if (is有值日生權限)
            {
                // 開啟篩選功能 及 送出訂單功能
                groupBox1.Visible = true;
                groupBox2.Visible = true;
                btn資料篩選.Visible = true;
                btn重置篩選.Visible = true;
                btn另存訂單.Visible = true;

                // 檢查有無訂單
                if (GlobalOrder.list訂單明細.Count > 0)
                {
                    // 只有管理員直接操作 GlobalOrder
                    if (is管理員)
                    {
                        // 顯示在UI
                        foreach (c訂單明細 item in GlobalOrder.list訂單明細)
                        {
                            c訂購單位 c單位 = (new c訂購單位Factory()).query指定訂購單位Id(item.a單位Id);
                            c訂購人 c人 = (new c訂購人Factory()).query訂購人(item.f訂購人Id);
                            c餐點 c餐 = (new c餐點Factory()).queryById(item.f餐點Id);
                            c餐廳 c店 = (new c餐廳Factory()).query餐廳(item.a餐廳Id);

                            lbox訂單列表.Items.Add($"{c單位.f訂購單位} {c人.f姓名}[{c人.fId}]：{c店.f餐廳名稱} {c餐.f餐點} {item.f數量}份 單價 {c餐.f價格} 元");
                        }
                        // 計算總價
                        total計算總價(GlobalOrder.list訂單明細);
                    }
                    // 值日生
                    else
                    {
                        // 限定只能 查看、刪除 單位訂單
                        list訂單明細Now.Clear();
                        int i = 0;
                        foreach (c訂單明細 item in GlobalOrder.list訂單明細)
                        {
                            if (item.a單位Id == GlobalOrder.e目前訂購單位.fId)
                            {
                                c訂單明細 x = new c訂單明細();
                                x.f訂購人Id = item.f訂購人Id;
                                x.f餐點Id = item.f餐點Id;
                                x.f數量 = item.f數量;
                                x.a單位Id = item.a單位Id;
                                x.a餐廳Id = item.a餐廳Id;
                                x.indexIn總訂單 = i;
                                list訂單明細Now.Add(x);
                            }
                            i++;
                        }

                        if (list訂單明細Now.Count > 0)
                        {
                            // 顯示在UI
                            foreach (c訂單明細 item in list訂單明細Now)
                            {
                                c訂購單位 c單位 = (new c訂購單位Factory()).query指定訂購單位Id(item.a單位Id);
                                c訂購人 c人 = (new c訂購人Factory()).query訂購人(item.f訂購人Id);
                                c餐點 c餐 = (new c餐點Factory()).queryById(item.f餐點Id);
                                c餐廳 c店 = (new c餐廳Factory()).query餐廳(item.a餐廳Id);

                                lbox訂單列表.Items.Add($"{c單位.f訂購單位} {c人.f姓名}[{c人.fId}]：{c店.f餐廳名稱} {c餐.f餐點} {item.f數量}份 單價 {c餐.f價格} 元");
                            }
                            // 計算總價
                            total計算總價(list訂單明細Now);
                        }
                    }
                }

                find訂單訂購單位();
                find訂單所有餐廳();
            }
            else
            {
                // 一般成員 去掉篩選功能 及 送出訂單功能
                groupBox1.Visible = false;
                groupBox2.Visible = false;
                btn資料篩選.Visible = false;
                btn重置篩選.Visible = false;
                btn另存訂單.Visible = false;

                // 檢查有無訂單
                if (GlobalOrder.list訂單明細.Count > 0)
                {
                    // 使用list訂單明細Now：限定只能 查看、刪除 自己的訂單
                    list訂單明細Now.Clear();
                    int i = 0;
                    foreach (c訂單明細 item in GlobalOrder.list訂單明細)
                    {
                        if (item.f訂購人Id == GlobalOrder.e目前訂購人.fId)
                        {
                            c訂單明細 x = new c訂單明細();
                            x.f訂購人Id = item.f訂購人Id;
                            x.f餐點Id = item.f餐點Id;
                            x.f數量 = item.f數量;
                            x.a單位Id = item.a單位Id;
                            x.a餐廳Id = item.a餐廳Id;
                            x.indexIn總訂單 = i;
                            list訂單明細Now.Add(x);
                        }
                        i++;
                    }

                    if (list訂單明細Now.Count > 0)
                    {
                        // 顯示在UI
                        foreach (c訂單明細 item in list訂單明細Now)
                        {
                            //c訂購單位 c單位 = (new c訂購單位Factory()).query指定訂購人(item.f訂購人Id);
                            c訂購單位 c單位 = (new c訂購單位Factory()).query指定訂購單位Id(item.a單位Id);
                            c訂購人 c人 = (new c訂購人Factory()).query訂購人(item.f訂購人Id);
                            c餐點 c餐 = (new c餐點Factory()).queryById(item.f餐點Id);
                            //c餐廳 c店 = (new c餐廳Factory()).query餐廳(c餐.f餐廳Id);
                            c餐廳 c店 = (new c餐廳Factory()).query餐廳(item.a餐廳Id);

                            lbox訂單列表.Items.Add($"{c單位.f訂購單位} {c人.f姓名}[{c人.fId}]：{c店.f餐廳名稱} {c餐.f餐點} {item.f數量}份 單價 {c餐.f價格} 元");
                        }
                        // 計算總價
                        total計算總價(list訂單明細Now);
                    }
                }
            }
        }

        private void lbox訂單列表_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        
        // ======================= 排序 =======================
        // 法1
        List<c餐廳> get總訂單所有餐廳()
        {
            if (GlobalOrder.list訂單明細.Count > 0)
            {
                // 取得 餐廳id 唯一值list
                List<int> list餐廳Id = new List<int>();
                foreach (c訂單明細 item in GlobalOrder.list訂單明細)
                {
                    c餐點 c餐 = (new c餐點Factory()).queryById(item.f餐點Id);
                    c餐廳 c店 = (new c餐廳Factory()).query餐廳(c餐.f餐廳Id);
                    list餐廳Id.Add(c店.fId);
                }
                var ordered = list餐廳Id.Distinct().OrderBy(n => n);
                // 餐廳id唯一值list 取得 餐廳list
                List<c餐廳> list餐廳 = new List<c餐廳>();
                foreach (var id in ordered)
                {
                    c餐廳 x = (new c餐廳Factory()).query餐廳(id);
                    list餐廳.Add(x);
                }
                return list餐廳;
            }
            else
            {
                return null;
            }
        }
        void rank所有訂單依照餐廳()
        {
            if (GlobalOrder.list訂單明細.Count > 0)
            {
                // 暫時裝排序好的訂單
                List<c訂單明細> list訂單明細temp = new List<c訂單明細>();
                foreach (c餐廳 store in get總訂單所有餐廳())
                {
                    foreach (c訂單明細 item in GlobalOrder.list訂單明細)
                    {
                        c餐點 c餐 = (new c餐點Factory()).queryById(item.f餐點Id);
                        c餐廳 c店 = (new c餐廳Factory()).query餐廳(c餐.f餐廳Id);
                        if (c店.fId == store.fId)
                        {
                            list訂單明細temp.Add(item);
                        }
                    }
                }
                GlobalOrder.list訂單明細 = list訂單明細temp;
            }
        }
        // 法2：LINQ
        void rank所有訂單依照餐廳2()
        {
            if (GlobalOrder.list訂單明細.Count > 0)
            {
                GlobalOrder.list訂單明細 = GlobalOrder.list訂單明細.OrderBy(order => order.a餐廳Id).ToList();
            }
        }

        // 直接針對 GlobalOrder 排序後，再全部載入
        private void btn餐廳排序_Click(object sender, EventArgs e)
        {
            //rank所有訂單依照餐廳();
            rank所有訂單依照餐廳2();
            reset訂單列表(GlobalOrder.e目前訂購人.f值日生權限);
        }

        // ====================== 搜尋選單 ======================
        void find訂單所有餐廳()
        {
            cbox餐廳.Items.Clear();
            // 非一般成員
            if (GlobalOrder.e目前訂購人.f值日生權限)
            {
                // 檢查有無訂單
                if (GlobalOrder.list訂單明細.Count > 0)
                {
                    // 只有管理員直接操作 GlobalOrder
                    if (is管理員)
                    {
                        // 加入內存
                        List<int> list餐廳id = GlobalOrder.list訂單明細.Select(order => order.a餐廳Id).Distinct().OrderBy(e => e).ToList();
                        list所有餐廳.Clear();
                        foreach (int id in list餐廳id)
                        {
                            list所有餐廳.Add((new c餐廳Factory()).query餐廳(id));
                        }
                        // 顯示UI
                        foreach (c餐廳 i in list所有餐廳)
                        {
                            cbox餐廳.Items.Add(i.f餐廳名稱);
                        }
                    }
                    // 值日生
                    else
                    {
                        // 加入內存
                        List<int> list餐廳id = list訂單明細Now.Select(order => order.a餐廳Id).Distinct().OrderBy(e => e).ToList();
                        list所有餐廳.Clear();
                        foreach (int id in list餐廳id)
                        {
                            list所有餐廳.Add((new c餐廳Factory()).query餐廳(id));
                        }
                        // 顯示UI
                        foreach (c餐廳 i in list所有餐廳)
                        {
                            cbox餐廳.Items.Add(i.f餐廳名稱);
                        }
                    }
                }
            }
        }

        void find訂單訂購單位()
        {
            cbox訂購單位.Items.Clear();
            // 非一般成員
            if (GlobalOrder.e目前訂購人.f值日生權限)
            {
                // 檢查有無訂單
                if (GlobalOrder.list訂單明細.Count > 0)
                {
                    // 管理員只顯示訂購單位(不預設選取 無訂購人列表)
                    if (is管理員)
                    {
                        // 加入內存
                        List<int> list訂購單位id = GlobalOrder.list訂單明細.Select(order => order.a單位Id).Distinct().OrderBy(e => e).ToList();
                        list所有訂購單位.Clear();
                        foreach (int id in list訂購單位id)
                        {
                            list所有訂購單位.Add((new c訂購單位Factory()).query指定訂購單位Id(id));
                        }
                        // 顯示UI
                        foreach (c訂購單位 i in list所有訂購單位)
                        {
                            cbox訂購單位.Items.Add(i.f訂購單位);
                        }
                    }
                    // 值日生
                    else
                    {
                        // 顯示UI：只顯示本單位
                        list所有訂購單位.Clear();
                        list所有訂購單位.Add(GlobalOrder.e目前訂購單位);
                        cbox訂購單位.Items.Add(GlobalOrder.e目前訂購單位.f訂購單位);

                        //// 預設本單位(不能先設定UI 否則進入搜尋模式)
                        //int搜尋訂購單位Id = GlobalOrder.e目前訂購單位.fId;
                        //// 對應訂購人(參數 訂購單位id)
                        //find訂購單位訂購人(int搜尋訂購單位Id);
                    }
                }
            }
        }

        // 加入內存 list目前單位訂購人 + 顯示UI
        void find訂購單位訂購人(int f訂購單位id)
        {
            cbox訂購人.Items.Clear();
            // 非一般成員
            if (GlobalOrder.e目前訂購人.f值日生權限)
            {
                // 檢查有無訂單
                if (GlobalOrder.list訂單明細.Count > 0)
                {
                    // 加入內存
                    List<int> list訂購人id = GlobalOrder.list訂單明細.Where(order => order.a單位Id == f訂購單位id).Select(order => order.f訂購人Id).Distinct().OrderBy(e => e).ToList();
                    list目前單位訂購人.Clear();
                    foreach (int id in list訂購人id)
                    {
                        list目前單位訂購人.Add((new c訂購人Factory()).query訂購人(id));
                    }
                    // 顯示UI
                    foreach (c訂購人 p in list目前單位訂購人)
                    {
                        cbox訂購人.Items.Add($"{p.f姓名}[{p.fId}]");
                    }
                }
            }
        }

        // ======================== 移除、清空 ========================
        // 移除訂單 listbox SelectionMode 改成可多選 MultiExtended
        private void btn移除訂單_Click(object sender, EventArgs e)
        {
            // 直接針對 GlobalOrder 移除，再全部載入
            if (is搜訂購)
            {
                // GlobalOrder中 移除
                for (int i = lbox訂單列表.SelectedIndices.Count - 1; i >= 0; i--)
                {
                    GlobalOrder.list訂單明細.RemoveAt(list搜尋訂單明細[lbox訂單列表.SelectedIndices[i]].indexIn總訂單);
                }
                int temp單位 = int搜尋訂購單位Id;
                int temp訂購人 = -1;
                // 搜訂購人
                if (int搜尋訂購人Id > -1)
                {
                    temp訂購人 = int搜尋訂購人Id;
                    // 重載搜尋
                    reset訂單列表(GlobalOrder.e目前訂購人.f值日生權限);
                    // ======== 先確認點選取訂購單位 ========
                    // 確認刪除條件存在
                    bool is刪除後包含搜尋單位 = false;
                    if (list所有訂購單位.Count > 0)
                    {
                        is刪除後包含搜尋單位 = list所有訂購單位.Select(org => org.fId).Contains(temp單位);
                    }
                    if (is刪除後包含搜尋單位)
                    {
                        // 找到訂購單位列表index
                        int[] x = list所有訂購單位.Select(org => org.fId).ToArray();
                        int index = Array.IndexOf(x, temp單位);
                        // 選訂購單位
                        int搜尋訂購單位Id = temp單位;
                        cbox訂購單位.SelectedIndex = index;

                        // ======== 再選取訂購人 ========
                        // 確認刪除條件存在
                        bool is刪除後包含搜尋訂購人 = false;
                        if (list目前單位訂購人.Count > 0)
                        {
                            is刪除後包含搜尋訂購人 = list目前單位訂購人.Select(p => p.fId).Contains(temp訂購人);
                        }
                        if (is刪除後包含搜尋訂購人)
                        {
                            // 找到訂購人列表index
                            int[] person = list目前單位訂購人.Select(p => p.fId).ToArray();
                            int indexPerson = Array.IndexOf(person, temp訂購人);
                            // 選訂購人
                            int搜尋訂購人Id = temp訂購人;
                            cbox訂購人.SelectedIndex = indexPerson;
                            // 按鈕
                            is搜訂購按鈕();
                        }
                    }
                }
                // 搜訂購單位
                else
                {
                    // 重載搜尋
                    reset訂單列表(GlobalOrder.e目前訂購人.f值日生權限);
                    // 確認刪除條件存在
                    bool is刪除後包含搜尋單位 = false;
                    if (list所有訂購單位.Count > 0)
                    {
                        is刪除後包含搜尋單位 = list所有訂購單位.Select(org => org.fId).Contains(temp單位);
                    }
                    if (is刪除後包含搜尋單位)
                    {
                        // 找到訂購單位列表index
                        int[] x = list所有訂購單位.Select(org => org.fId).ToArray();
                        int index = Array.IndexOf(x, temp單位);
                        // 選訂購單位
                        int搜尋訂購單位Id = temp單位;
                        cbox訂購單位.SelectedIndex = index;
                        // 按鈕
                        is搜訂購按鈕();
                    }
                }
            }
            else if (is搜餐廳)
            {
                // GlobalOrder中 移除
                for (int i = lbox訂單列表.SelectedIndices.Count - 1; i >= 0; i--)
                {
                    GlobalOrder.list訂單明細.RemoveAt(list搜尋訂單明細[lbox訂單列表.SelectedIndices[i]].indexIn總訂單);
                }
                int temp = int搜尋餐廳Id;
                // 重載搜尋
                reset訂單列表(GlobalOrder.e目前訂購人.f值日生權限);
                // 確認刪除條件存在
                bool is刪除後包含搜尋餐廳 = false;
                if (list所有餐廳.Count > 0)
                {
                    is刪除後包含搜尋餐廳 = list所有餐廳.Select(store => store.fId).Contains(temp);
                }
                if (is刪除後包含搜尋餐廳)
                {
                    // 找到餐廳列表index
                    int[] x = list所有餐廳.Select(store => store.fId).ToArray();
                    int index = Array.IndexOf(x, temp);
                    // 選餐廳
                    int搜尋餐廳Id = list所有餐廳[index].fId;
                    cbox餐廳.SelectedIndex = index;
                    // 按鈕
                    is搜餐廳按鈕();
                }
            }
            else
            {
                if (is管理員)
                {
                    for (int i = lbox訂單列表.SelectedIndices.Count - 1; i >= 0; i--)
                    {
                        GlobalOrder.list訂單明細.RemoveAt(lbox訂單列表.SelectedIndices[i]);
                    }
                }
                else
                {
                    for (int i = lbox訂單列表.SelectedIndices.Count - 1; i >= 0; i--)
                    {
                        GlobalOrder.list訂單明細.RemoveAt(list訂單明細Now[lbox訂單列表.SelectedIndices[i]].indexIn總訂單);
                    }
                }
                reset訂單列表(GlobalOrder.e目前訂購人.f值日生權限);
            }
        }

        private void btn全部清空_Click(object sender, EventArgs e)
        {
            // 直接針對 GlobalOrder 移除 目前篩選條件物件，再全部載入(未篩選狀態)
            if ( (is搜訂購) || (is搜餐廳) )
            {
                for (int i = list搜尋訂單明細.Count - 1; i >= 0; i--)
                {
                    GlobalOrder.list訂單明細.RemoveAt(list搜尋訂單明細[i].indexIn總訂單);
                }
                reset訂單列表(GlobalOrder.e目前訂購人.f值日生權限);
            }
            else
            {
                if (is管理員)
                {
                    GlobalOrder.list訂單明細.Clear();
                }
                else
                {
                    for (int i = list訂單明細Now.Count - 1; i >= 0; i--)
                    {
                        GlobalOrder.list訂單明細.RemoveAt(list訂單明細Now[i].indexIn總訂單);
                    }
                }
                reset訂單列表(GlobalOrder.e目前訂購人.f值日生權限);
            }
        }

        // ======================= 搜尋 =======================
        private void cbox訂購單位_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbox訂購單位.SelectedIndex > -1)
            {
                // 正在搜訂購，不可搜餐廳
                is搜訂購 = true;
                is搜餐廳 = false;
                cbox餐廳.Enabled = false;

                // 內存初始化
                int搜尋訂購人Id = -1;
                // UI初始化
                cbox訂購人.Text = "";

                // 內存
                int搜尋訂購單位Id = list所有訂購單位[cbox訂購單位.SelectedIndex].fId;
                // 對應的訂購人列表
                find訂購單位訂購人(int搜尋訂購單位Id);
            }
        }

        private void cbox訂購人_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbox訂購人.SelectedIndex > -1)
            {
                // 正在搜訂購，不可搜餐廳
                is搜訂購 = true;
                is搜餐廳 = false;
                cbox餐廳.Enabled = false;

                // 內存
                int搜尋訂購人Id = list目前單位訂購人[cbox訂購人.SelectedIndex].fId;
            }
        }
        
        private void cbox餐廳_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbox餐廳.SelectedIndex > -1)
            {
                // 正在搜餐廳，不可搜訂購
                is搜訂購 = false;
                is搜餐廳 = true;
                cbox訂購單位.Enabled = false;
                cbox訂購人.Enabled = false;

                // 內存
                int搜尋餐廳Id = list所有餐廳[cbox餐廳.SelectedIndex].fId;
            }
        }
        
        private void btn資料篩選_Click(object sender, EventArgs e)
        {
            if (is搜訂購)
            {
                is搜訂購按鈕();
            }
            else if (is搜餐廳)
            {
                is搜餐廳按鈕();
            }
            else
            {
                MessageBox.Show("請選擇篩選條件！", "篩選結果", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        void is搜訂購按鈕()
        {
            // 篩選狀態禁止排序
            btn餐廳排序.Enabled = false;

            // UI
            lbox訂單列表.Items.Clear();

            // 檢查有無訂單
            if (GlobalOrder.list訂單明細.Count > 0)
            {
                // 有搜尋訂購人
                if (int搜尋訂購人Id > -1)
                {
                    if (is管理員)
                    {
                        // 加入內存
                        list搜尋訂單明細.Clear();
                        int i = 0;
                        foreach (c訂單明細 item in GlobalOrder.list訂單明細)
                        {
                            if (item.f訂購人Id == int搜尋訂購人Id)
                            {
                                c訂單明細 x = new c訂單明細();
                                x.f訂購人Id = item.f訂購人Id;
                                x.f餐點Id = item.f餐點Id;
                                x.f數量 = item.f數量;
                                x.a單位Id = item.a單位Id;
                                x.a餐廳Id = item.a餐廳Id;
                                x.indexIn總訂單 = i;
                                list搜尋訂單明細.Add(x);
                            }
                            i++;
                        }

                        if (list搜尋訂單明細.Count > 0)
                        {
                            // 顯示在UI
                            foreach (c訂單明細 item in list搜尋訂單明細)
                            {
                                c訂購單位 c單位 = (new c訂購單位Factory()).query指定訂購單位Id(item.a單位Id);
                                c訂購人 c人 = (new c訂購人Factory()).query訂購人(item.f訂購人Id);
                                c餐點 c餐 = (new c餐點Factory()).queryById(item.f餐點Id);
                                c餐廳 c店 = (new c餐廳Factory()).query餐廳(item.a餐廳Id);

                                lbox訂單列表.Items.Add($"{c單位.f訂購單位} {c人.f姓名}[{c人.fId}]：{c店.f餐廳名稱} {c餐.f餐點} {item.f數量}份 單價 {c餐.f價格} 元");
                            }
                            // 計算總價
                            total計算總價(list搜尋訂單明細);
                        }
                    }
                    // 值日生
                    else
                    {
                        // 加入內存
                        list搜尋訂單明細.Clear();
                        foreach (c訂單明細 item in list訂單明細Now)
                        {
                            if (item.f訂購人Id == int搜尋訂購人Id)
                            {
                                c訂單明細 x = new c訂單明細();
                                x.f訂購人Id = item.f訂購人Id;
                                x.f餐點Id = item.f餐點Id;
                                x.f數量 = item.f數量;
                                x.a單位Id = item.a單位Id;
                                x.a餐廳Id = item.a餐廳Id;
                                x.indexIn總訂單 = item.indexIn總訂單;
                                list搜尋訂單明細.Add(x);
                            }
                        }

                        if (list搜尋訂單明細.Count > 0)
                        {
                            // 顯示在UI
                            foreach (c訂單明細 item in list搜尋訂單明細)
                            {
                                c訂購單位 c單位 = (new c訂購單位Factory()).query指定訂購單位Id(item.a單位Id);
                                c訂購人 c人 = (new c訂購人Factory()).query訂購人(item.f訂購人Id);
                                c餐點 c餐 = (new c餐點Factory()).queryById(item.f餐點Id);
                                c餐廳 c店 = (new c餐廳Factory()).query餐廳(item.a餐廳Id);

                                lbox訂單列表.Items.Add($"{c單位.f訂購單位} {c人.f姓名}[{c人.fId}]：{c店.f餐廳名稱} {c餐.f餐點} {item.f數量}份 單價 {c餐.f價格} 元");
                            }
                            // 計算總價
                            total計算總價(list搜尋訂單明細);
                        }
                    }
                }
                // 只搜尋訂購單位
                else
                {
                    // 只有管理員才需要
                    if (is管理員)
                    {
                        // 加入內存
                        list搜尋訂單明細.Clear();
                        int i = 0;
                        foreach (c訂單明細 item in GlobalOrder.list訂單明細)
                        {
                            if (item.a單位Id == int搜尋訂購單位Id)
                            {
                                c訂單明細 x = new c訂單明細();
                                x.f訂購人Id = item.f訂購人Id;
                                x.f餐點Id = item.f餐點Id;
                                x.f數量 = item.f數量;
                                x.a單位Id = item.a單位Id;
                                x.a餐廳Id = item.a餐廳Id;
                                x.indexIn總訂單 = i;
                                list搜尋訂單明細.Add(x);
                            }
                            i++;
                        }

                        if (list搜尋訂單明細.Count > 0)
                        {
                            // 顯示在UI
                            foreach (c訂單明細 item in list搜尋訂單明細)
                            {
                                c訂購單位 c單位 = (new c訂購單位Factory()).query指定訂購單位Id(item.a單位Id);
                                c訂購人 c人 = (new c訂購人Factory()).query訂購人(item.f訂購人Id);
                                c餐點 c餐 = (new c餐點Factory()).queryById(item.f餐點Id);
                                c餐廳 c店 = (new c餐廳Factory()).query餐廳(item.a餐廳Id);

                                lbox訂單列表.Items.Add($"{c單位.f訂購單位} {c人.f姓名}[{c人.fId}]：{c店.f餐廳名稱} {c餐.f餐點} {item.f數量}份 單價 {c餐.f價格} 元");
                            }
                            // 計算總價
                            total計算總價(list搜尋訂單明細);
                        }
                    }
                    // 值日生直接重置未搜尋狀態
                    else
                    {
                        reset訂單列表(GlobalOrder.e目前訂購人.f值日生權限);
                    }
                }
            }
        }

        void is搜餐廳按鈕()
        {
            // 篩選狀態禁止排序
            btn餐廳排序.Enabled = false;

            // UI
            lbox訂單列表.Items.Clear();

            // 檢查有無訂單
            if (GlobalOrder.list訂單明細.Count > 0)
            {
                // 只有管理員直接操作 GlobalOrder
                if (is管理員)
                {
                    // 加入內存
                    list搜尋訂單明細.Clear();
                    int i = 0;
                    foreach (c訂單明細 item in GlobalOrder.list訂單明細)
                    {
                        if (item.a餐廳Id == int搜尋餐廳Id)
                        {
                            c訂單明細 x = new c訂單明細();
                            x.f訂購人Id = item.f訂購人Id;
                            x.f餐點Id = item.f餐點Id;
                            x.f數量 = item.f數量;
                            x.a單位Id = item.a單位Id;
                            x.a餐廳Id = item.a餐廳Id;
                            x.indexIn總訂單 = i;
                            list搜尋訂單明細.Add(x);
                        }
                        i++;
                    }

                    if (list搜尋訂單明細.Count > 0)
                    {
                        // 顯示在UI
                        foreach (c訂單明細 item in list搜尋訂單明細)
                        {
                            c訂購單位 c單位 = (new c訂購單位Factory()).query指定訂購單位Id(item.a單位Id);
                            c訂購人 c人 = (new c訂購人Factory()).query訂購人(item.f訂購人Id);
                            c餐點 c餐 = (new c餐點Factory()).queryById(item.f餐點Id);
                            c餐廳 c店 = (new c餐廳Factory()).query餐廳(item.a餐廳Id);

                            lbox訂單列表.Items.Add($"{c單位.f訂購單位} {c人.f姓名}[{c人.fId}]：{c店.f餐廳名稱} {c餐.f餐點} {item.f數量}份 單價 {c餐.f價格} 元");
                        }
                        // 計算總價
                        total計算總價(list搜尋訂單明細);
                    }
                }
                // 值日生
                else
                {
                    // 加入內存
                    list搜尋訂單明細.Clear();
                    foreach (c訂單明細 item in list訂單明細Now)
                    {
                        if (item.a餐廳Id == int搜尋餐廳Id)
                        {
                            c訂單明細 x = new c訂單明細();
                            x.f訂購人Id = item.f訂購人Id;
                            x.f餐點Id = item.f餐點Id;
                            x.f數量 = item.f數量;
                            x.a單位Id = item.a單位Id;
                            x.a餐廳Id = item.a餐廳Id;
                            x.indexIn總訂單 = item.indexIn總訂單;
                            list搜尋訂單明細.Add(x);
                        }
                    }

                    if (list搜尋訂單明細.Count > 0)
                    {
                        // 顯示在UI
                        foreach (c訂單明細 item in list搜尋訂單明細)
                        {
                            c訂購單位 c單位 = (new c訂購單位Factory()).query指定訂購單位Id(item.a單位Id);
                            c訂購人 c人 = (new c訂購人Factory()).query訂購人(item.f訂購人Id);
                            c餐點 c餐 = (new c餐點Factory()).queryById(item.f餐點Id);
                            c餐廳 c店 = (new c餐廳Factory()).query餐廳(item.a餐廳Id);

                            lbox訂單列表.Items.Add($"{c單位.f訂購單位} {c人.f姓名}[{c人.fId}]：{c店.f餐廳名稱} {c餐.f餐點} {item.f數量}份 單價 {c餐.f價格} 元");
                        }
                        // 計算總價
                        total計算總價(list搜尋訂單明細);
                    }
                }
            }
        }

        private void btn重置篩選_Click(object sender, EventArgs e)
        {
            reset訂單列表(GlobalOrder.e目前訂購人.f值日生權限);
        }

        // ======================= 另存 =======================
        private void btn另存訂單_Click(object sender, EventArgs e)
        {
            try
            {
                // ====================== 開啟檔案存取器 ======================
                string str完整路徑 = "";
                // 開啟檔案存取器
                SaveFileDialog sfd = new SaveFileDialog();
                // 可以使用的檔名
                sfd.Filter = "Txt File|*.txt";

                // 預設目錄
                //sfd.InitialDirectory = @"C:\Users";
                // 預設檔名
                Random myRnd = new Random();
                int myRndNum = myRnd.Next(1000, 10000);
                string str檔名 = DateTime.Now.ToString("yyyyMMdd_HHmmss_") + myRndNum.ToString() + "_" + GlobalOrder.e目前訂購單位.f訂購單位 + @"_吃貨訂購單.txt";
                sfd.FileName = str檔名;

                // 檔案存取器 對話框show(使用者沒有選取 就return不繼續存檔動作)
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    str完整路徑 = sfd.FileName;
                }
                else
                {
                    return;
                }

                // ====================== 每一行寫成一個list元素 ======================
                List<string> lines所有訂單 = new List<string>();
                
                // 表頭、時間
                lines所有訂單.Add("============ Baby點餐機 吃貨訂購單 ============");
                lines所有訂單.Add("訂購時間：" + DateTime.Now.ToString());
                lines所有訂單.Add("=============================================");
                
                // 依照權限來自不同列表
                List<c訂單明細> list統一訂單列表;
                if (is管理員)
                    list統一訂單列表 = GlobalOrder.list訂單明細;
                else
                    list統一訂單列表 = list訂單明細Now;
                
                // 依照餐廳列表
                int total店小計金額;
                int total餐小計金額;
                int total餐小計數量;
                foreach (c餐廳 store in list所有餐廳)
                {
                    lines所有訂單.Add($"======== {store.f餐廳名稱}[{store.f餐廳電話}] ========");
                    // 店小計
                    total店小計金額 = 0;
                    
                    // 依照餐點列表
                    List<c餐點> list指定餐點 = find指定餐廳在列表中所有餐點(store.fId, list統一訂單列表);
                    foreach (c餐點 food in list指定餐點)
                    {
                        lines所有訂單.Add($"【{food.f餐點}】");
                        // 餐小計
                        total餐小計金額 = 0;
                        total餐小計數量 = 0;
                        foreach (c訂單明細 item in list統一訂單列表)
                        {
                            c訂購單位 c單位 = (new c訂購單位Factory()).query指定訂購單位Id(item.a單位Id);
                            c訂購人 c人 = (new c訂購人Factory()).query訂購人(item.f訂購人Id);
                            c餐點 c餐 = (new c餐點Factory()).queryById(item.f餐點Id);
                            c餐廳 c店 = (new c餐廳Factory()).query餐廳(item.a餐廳Id);

                            if (food.fId == c餐.fId)
                            {
                                // 店小計
                                total店小計金額 += item.f數量 * c餐.f價格;
                                // 餐小計
                                total餐小計金額 += item.f數量 * c餐.f價格;
                                total餐小計數量 += item.f數量;
                                lines所有訂單.Add($"{c單位.f訂購單位} {c人.f姓名}[{c人.fId}]：訂購 {c餐.f價格}元 x {item.f數量}個");
                            }
                        }
                        lines所有訂單.Add($"【餐小計：{total餐小計數量}個 {total餐小計金額} 元】");
                        lines所有訂單.Add($"----------------------");
                    }
                    lines所有訂單.Add($"===== 店小計：{total店小計金額} 元 =====");
                }

                // 結尾總計
                lines所有訂單.Add("=============================================");
                lines所有訂單.Add("總價：" + total計算總價(list統一訂單列表) + " 元");

                // 寫入品項檔案
                System.IO.File.WriteAllLines(str完整路徑, lines所有訂單, Encoding.UTF8);
                MessageBox.Show("另存訂單成功！", "另存訂單結果", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception error)
            {
                MessageBox.Show("另存訂單失敗：" + Convert.ToString(error), "另存訂單結果");
            }
        }

        // 指定餐廳id + 訂單列表，取得該餐廳所有餐點
        List<c餐點> find指定餐廳在列表中所有餐點(int f餐廳Id, List<c訂單明細> list訂單明細)
        {
            // 取得所有餐點 id唯一list
            int[] x = list訂單明細.Where(order => order.a餐廳Id == f餐廳Id).Select(order => order.f餐點Id).Distinct().OrderBy(e => e).ToArray();
            // 轉成 List<c餐點>
            List<c餐點> list指定餐點 = new List<c餐點>();
            foreach (int id餐點 in x)
            {
                c餐點 c餐 = (new c餐點Factory()).queryById(id餐點);
                list指定餐點.Add(c餐);
            }
            return list指定餐點;
        }
    }
}