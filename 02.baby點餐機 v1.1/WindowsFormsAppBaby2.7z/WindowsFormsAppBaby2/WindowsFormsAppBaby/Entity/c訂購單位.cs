﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsAppBaby
{
    class c訂購單位
    {
        public int fId { get; set; }
        public string f訂購單位 { get; set; }
    }
}
