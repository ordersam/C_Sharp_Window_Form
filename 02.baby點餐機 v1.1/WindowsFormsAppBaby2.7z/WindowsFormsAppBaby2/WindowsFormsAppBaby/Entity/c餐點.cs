﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsAppBaby.Entity
{
    class c餐點
    {
        public int fId { get; set; }
        public int f分類Id { get; set; }
        public int f餐廳Id { get; set; }
        public string f餐點 { get; set; }
        public int f價格 { get; set; }
        public string f圖片 { get; set; }
    }
}
