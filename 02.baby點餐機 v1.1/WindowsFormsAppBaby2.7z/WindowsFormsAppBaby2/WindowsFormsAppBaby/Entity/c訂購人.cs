﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsAppBaby.Entity
{
    class c訂購人
    {
        public int fId { get; set; }
        public string f姓名 { get; set; }
        public string f密碼 { get; set; }
        public int f訂購單位Id { get; set; }
        public bool f值日生權限 { get; set; }
    }
}
