﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsAppBaby.Entity
{
    class c訂單明細
    {
        // 送出訂單 寫入資料庫再生成
        public int fId { get; set; }
        public int f訂單Id { get; set; }

        // 可內存使用
        public int f訂購人Id { get; set; }
        public int f餐點Id { get; set; }
        public int f數量 { get; set; }

        // =================== 非table欄位 ===================
        // 紀錄訂購單位id
        public int a單位Id { get; set; }
        // 紀錄餐廳id
        public int a餐廳Id { get; set; }

        // 紀錄目前index(部分權限、篩選使用) -> 暫存到 list訂單明細Now
        public int indexIn總訂單 { get; set; }
    }
}
