﻿namespace WindowsFormsAppBaby
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cbox訂購單位 = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbox訂購人 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn資料篩選 = new System.Windows.Forms.Button();
            this.lbox訂單列表 = new System.Windows.Forms.ListBox();
            this.cbox餐廳 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbl總計 = new System.Windows.Forms.Label();
            this.btn移除訂單 = new System.Windows.Forms.Button();
            this.btn全部清空 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn重置篩選 = new System.Windows.Forms.Button();
            this.btn另存訂單 = new System.Windows.Forms.Button();
            this.btn餐廳排序 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(-1, -2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(793, 46);
            this.label1.TabIndex = 0;
            this.label1.Text = "=== 吃貨訂購單 ===";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label2.Location = new System.Drawing.Point(6, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "訂購單位";
            // 
            // cbox訂購單位
            // 
            this.cbox訂購單位.FormattingEnabled = true;
            this.cbox訂購單位.Location = new System.Drawing.Point(100, 25);
            this.cbox訂購單位.Name = "cbox訂購單位";
            this.cbox訂購單位.Size = new System.Drawing.Size(168, 32);
            this.cbox訂購單位.TabIndex = 2;
            this.cbox訂購單位.SelectedIndexChanged += new System.EventHandler(this.cbox訂購單位_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Wheat;
            this.groupBox1.Controls.Add(this.cbox訂購人);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.cbox訂購單位);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(12, 349);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(287, 103);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "訂購方篩選";
            // 
            // cbox訂購人
            // 
            this.cbox訂購人.FormattingEnabled = true;
            this.cbox訂購人.Location = new System.Drawing.Point(100, 63);
            this.cbox訂購人.Name = "cbox訂購人";
            this.cbox訂購人.Size = new System.Drawing.Size(168, 32);
            this.cbox訂購人.TabIndex = 4;
            this.cbox訂購人.SelectedIndexChanged += new System.EventHandler(this.cbox訂購人_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label3.Location = new System.Drawing.Point(6, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 24);
            this.label3.TabIndex = 3;
            this.label3.Text = "訂購人";
            // 
            // btn資料篩選
            // 
            this.btn資料篩選.BackColor = System.Drawing.Color.Red;
            this.btn資料篩選.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn資料篩選.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn資料篩選.Location = new System.Drawing.Point(568, 349);
            this.btn資料篩選.Name = "btn資料篩選";
            this.btn資料篩選.Size = new System.Drawing.Size(139, 103);
            this.btn資料篩選.TabIndex = 8;
            this.btn資料篩選.Text = "資料篩選";
            this.btn資料篩選.UseVisualStyleBackColor = false;
            this.btn資料篩選.Click += new System.EventHandler(this.btn資料篩選_Click);
            // 
            // lbox訂單列表
            // 
            this.lbox訂單列表.BackColor = System.Drawing.Color.Purple;
            this.lbox訂單列表.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.lbox訂單列表.FormattingEnabled = true;
            this.lbox訂單列表.ItemHeight = 24;
            this.lbox訂單列表.Location = new System.Drawing.Point(12, 50);
            this.lbox訂單列表.Name = "lbox訂單列表";
            this.lbox訂單列表.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lbox訂單列表.Size = new System.Drawing.Size(765, 244);
            this.lbox訂單列表.TabIndex = 4;
            this.lbox訂單列表.SelectedIndexChanged += new System.EventHandler(this.lbox訂單列表_SelectedIndexChanged);
            // 
            // cbox餐廳
            // 
            this.cbox餐廳.FormattingEnabled = true;
            this.cbox餐廳.Location = new System.Drawing.Point(10, 60);
            this.cbox餐廳.Name = "cbox餐廳";
            this.cbox餐廳.Size = new System.Drawing.Size(217, 32);
            this.cbox餐廳.TabIndex = 6;
            this.cbox餐廳.SelectedIndexChanged += new System.EventHandler(this.cbox餐廳_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Maroon;
            this.label4.Location = new System.Drawing.Point(6, 28);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 24);
            this.label4.TabIndex = 5;
            this.label4.Text = "餐廳";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(349, 312);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 24);
            this.label5.TabIndex = 5;
            this.label5.Text = "總計";
            // 
            // lbl總計
            // 
            this.lbl總計.BackColor = System.Drawing.Color.DarkSlateGray;
            this.lbl總計.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl總計.Location = new System.Drawing.Point(403, 302);
            this.lbl總計.Name = "lbl總計";
            this.lbl總計.Size = new System.Drawing.Size(150, 42);
            this.lbl總計.TabIndex = 6;
            this.lbl總計.Text = "XX 元";
            this.lbl總計.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn移除訂單
            // 
            this.btn移除訂單.BackColor = System.Drawing.Color.DarkBlue;
            this.btn移除訂單.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn移除訂單.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn移除訂單.Location = new System.Drawing.Point(130, 300);
            this.btn移除訂單.Name = "btn移除訂單";
            this.btn移除訂單.Size = new System.Drawing.Size(104, 45);
            this.btn移除訂單.TabIndex = 7;
            this.btn移除訂單.Text = "移除訂單";
            this.btn移除訂單.UseVisualStyleBackColor = false;
            this.btn移除訂單.Click += new System.EventHandler(this.btn移除訂單_Click);
            // 
            // btn全部清空
            // 
            this.btn全部清空.BackColor = System.Drawing.Color.Crimson;
            this.btn全部清空.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn全部清空.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn全部清空.Location = new System.Drawing.Point(239, 300);
            this.btn全部清空.Name = "btn全部清空";
            this.btn全部清空.Size = new System.Drawing.Size(104, 45);
            this.btn全部清空.TabIndex = 8;
            this.btn全部清空.Text = "全部清空";
            this.btn全部清空.UseVisualStyleBackColor = false;
            this.btn全部清空.Click += new System.EventHandler(this.btn全部清空_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.cbox餐廳);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(305, 349);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(248, 103);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "餐廳篩選";
            // 
            // btn重置篩選
            // 
            this.btn重置篩選.BackColor = System.Drawing.Color.Black;
            this.btn重置篩選.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn重置篩選.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn重置篩選.Location = new System.Drawing.Point(713, 349);
            this.btn重置篩選.Name = "btn重置篩選";
            this.btn重置篩選.Size = new System.Drawing.Size(64, 103);
            this.btn重置篩選.TabIndex = 8;
            this.btn重置篩選.Text = "重置篩選";
            this.btn重置篩選.UseVisualStyleBackColor = false;
            this.btn重置篩選.Click += new System.EventHandler(this.btn重置篩選_Click);
            // 
            // btn另存訂單
            // 
            this.btn另存訂單.BackColor = System.Drawing.Color.Indigo;
            this.btn另存訂單.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn另存訂單.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn另存訂單.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn另存訂單.Location = new System.Drawing.Point(568, 300);
            this.btn另存訂單.Name = "btn另存訂單";
            this.btn另存訂單.Size = new System.Drawing.Size(209, 45);
            this.btn另存訂單.TabIndex = 11;
            this.btn另存訂單.Text = "送出訂單(另存)";
            this.btn另存訂單.UseVisualStyleBackColor = false;
            this.btn另存訂單.Click += new System.EventHandler(this.btn另存訂單_Click);
            // 
            // btn餐廳排序
            // 
            this.btn餐廳排序.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn餐廳排序.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn餐廳排序.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn餐廳排序.Location = new System.Drawing.Point(12, 299);
            this.btn餐廳排序.Name = "btn餐廳排序";
            this.btn餐廳排序.Size = new System.Drawing.Size(112, 45);
            this.btn餐廳排序.TabIndex = 12;
            this.btn餐廳排序.Text = "餐廳排序";
            this.btn餐廳排序.UseVisualStyleBackColor = false;
            this.btn餐廳排序.Click += new System.EventHandler(this.btn餐廳排序_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(789, 465);
            this.Controls.Add(this.btn餐廳排序);
            this.Controls.Add(this.btn另存訂單);
            this.Controls.Add(this.btn資料篩選);
            this.Controls.Add(this.btn重置篩選);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btn全部清空);
            this.Controls.Add(this.btn移除訂單);
            this.Controls.Add(this.lbl總計);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lbox訂單列表);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Baby點餐機 v1.1";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbox訂購單位;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbox訂購人;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox lbox訂單列表;
        private System.Windows.Forms.ComboBox cbox餐廳;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbl總計;
        private System.Windows.Forms.Button btn移除訂單;
        private System.Windows.Forms.Button btn全部清空;
        private System.Windows.Forms.Button btn資料篩選;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn重置篩選;
        private System.Windows.Forms.Button btn另存訂單;
        private System.Windows.Forms.Button btn餐廳排序;
    }
}