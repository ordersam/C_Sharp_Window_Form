﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsAppBaby.Entity;

namespace WindowsFormsAppBaby.Factory
{
    class c餐點Factory
    {
        // 指定 分類id+餐廳id 之下的餐點
        public List<c餐點> queryBy點餐分類(int f分類Id, int f餐廳Id)
        {
            List<c餐點> list = queryBysql($"select * from t餐點 where f分類Id = {f分類Id} and f餐廳Id = {f餐廳Id}");
            // 沒找到回傳空值
            if (list.Count == 0)
                return null;
            return list;
        }

        // 指定餐點id 找到餐點
        public c餐點 queryById(int fId)
        {
            List<c餐點> list = queryBysql($"select * from t餐點 where fId = {fId}");
            // 沒找到回傳空值
            if (list.Count == 0)
                return null;
            return list[0];
        }

        public List<c餐點> queryBysql(string sql)
        {
            // 1.接水管
            SqlConnection con = new SqlConnection(GlobalVar.sqlstring);
            con.Open();
            // 2.開水龍頭
            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            // 3.放水桶
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            con.Close();

            List<c餐點> list = new List<c餐點>();
            foreach (DataRow r in ds.Tables[0].Rows)
            {
                c餐點 x = new c餐點();
                x.fId = Convert.ToInt32(r["fId"].ToString());
                x.f分類Id = Convert.ToInt32(r["f分類Id"].ToString());
                x.f餐廳Id = Convert.ToInt32(r["f餐廳Id"].ToString());
                x.f餐點 = r["f餐點"].ToString();
                x.f價格 = Convert.ToInt32(r["f價格"].ToString());
                x.f圖片 = r["f圖片"].ToString();
                list.Add(x);
            }
            return list;
        }
    }
}
