﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsAppBaby.Entity;

namespace WindowsFormsAppBaby.Factory
{
    class c點餐分類Factory
    {
        // ====================== 查詢 ======================
        public List<c點餐分類> queryAll點餐分類()
        {
            List<c點餐分類> list = queryBysql("select * from t點餐分類");
            // 沒找到回傳空值
            if (list.Count == 0)
                return null;
            return list;
        }

        public List<c點餐分類> queryBysql(string sql)
        {
            // 1.接水管
            SqlConnection con = new SqlConnection(GlobalVar.sqlstring);
            con.Open();
            // 2.開水龍頭
            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            // 3.放水桶
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            con.Close();

            List<c點餐分類> list = new List<c點餐分類>();
            foreach (DataRow r in ds.Tables[0].Rows)
            {
                c點餐分類 x = new c點餐分類();
                x.fId = Convert.ToInt32(r["fId"].ToString());
                x.f分類 = r["f分類"].ToString();
                x.f圖片 = r["f圖片"].ToString();
                list.Add(x);
            }
            return list;
        }
    }
}
