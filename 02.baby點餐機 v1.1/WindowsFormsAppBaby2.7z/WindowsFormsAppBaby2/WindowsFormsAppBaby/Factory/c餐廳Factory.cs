﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsAppBaby.Entity;

namespace WindowsFormsAppBaby.Factory
{
    class c餐廳Factory
    {
        // ====================== 查詢 ======================
        public List<c餐廳> queryAll餐廳()
        {
            List<c餐廳> list = queryBysql("select * from t餐廳");
            // 沒找到回傳空值
            if (list.Count == 0)
                return null;
            return list;
        }

        // 指定 分類id 之下的餐廳
        public List<c餐廳> queryBy點餐分類(int fId)
        {
            List<c餐廳> list = queryBysql("select distinct B.fId, B.f餐廳名稱, B.f餐廳電話, B.f餐廳地址 from t餐點 as A join t餐廳 as B on A.f餐廳Id = B.fId where A.f分類Id = " + fId);
            // 沒找到回傳空值
            if (list.Count == 0)
                return null;
            return list;
        }

        // 指定餐廳id 找到餐廳
        public c餐廳 query餐廳(int fId)
        {
            List<c餐廳> list = queryBysql($"select * from t餐廳 where fId = {fId}");
            // 沒找到回傳空值
            if (list.Count == 0)
                return null;
            return list[0];
        }

        public List<c餐廳> queryBysql(string sql)
        {
            // 1.接水管
            SqlConnection con = new SqlConnection(GlobalVar.sqlstring);
            con.Open();
            // 2.開水龍頭
            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            // 3.放水桶
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            con.Close();

            List<c餐廳> list = new List<c餐廳>();
            foreach (DataRow r in ds.Tables[0].Rows)
            {
                c餐廳 x = new c餐廳();
                x.fId = Convert.ToInt32(r["fId"].ToString());
                x.f餐廳名稱 = r["f餐廳名稱"].ToString();
                x.f餐廳電話 = r["f餐廳電話"].ToString();
                x.f餐廳地址 = r["f餐廳地址"].ToString();
                list.Add(x);
            }
            return list;
        }
    }
}
