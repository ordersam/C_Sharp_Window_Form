﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsAppBaby.Entity;

namespace WindowsFormsAppBaby.Factory
{
    class c訂購人Factory
    {
        // ====================== 查詢 ======================
        // 指定訂購單位id 找到 List<c訂購人>
        public List<c訂購人> query單位訂購人(int fId)
        {
            List<c訂購人> list = queryBysql($"select * from t訂購人 where f訂購單位Id = {fId}");
            // 沒找到回傳空值
            if (list.Count == 0)
                return null;
            return list;
        }

        // 指定訂購單位id 找到 單位值日生
        public c訂購人 query單位值日生(int fId)
        {
            List<c訂購人> list = queryBysql($"select * from t訂購人 where f訂購單位Id = {fId} and f值日生權限 = 1");
            // 沒找到回傳空值
            if (list.Count == 0)
                return null;
            return list[0];
        }

        // 指定訂購人id 找到訂購人
        public c訂購人 query訂購人(int fId)
        {
            List<c訂購人> list = queryBysql($"select * from t訂購人 where fId = {fId}");
            // 沒找到回傳空值
            if (list.Count == 0)
                return null;
            return list[0];
        }

        public List<c訂購人> queryBysql(string sql)
        {
            // 1.接水管
            SqlConnection con = new SqlConnection(GlobalVar.sqlstring);
            con.Open();
            // 2.開水龍頭
            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            // 3.放水桶
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            con.Close();

            List<c訂購人> list = new List<c訂購人>();
            foreach (DataRow r in ds.Tables[0].Rows)
            {
                c訂購人 x = new c訂購人();
                x.fId = Convert.ToInt32(r["fId"].ToString());
                x.f姓名 = r["f姓名"].ToString();
                x.f密碼 = r["f密碼"].ToString();
                x.f訂購單位Id = Convert.ToInt32(r["f訂購單位Id"].ToString());
                x.f值日生權限 = (bool)r["f值日生權限"];
                list.Add(x);
            }
            return list;
        }
    }
}
