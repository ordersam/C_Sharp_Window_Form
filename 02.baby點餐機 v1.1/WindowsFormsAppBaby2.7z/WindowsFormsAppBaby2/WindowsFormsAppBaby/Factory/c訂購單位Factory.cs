﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsAppBaby.Entity;

namespace WindowsFormsAppBaby.Factory
{
    class c訂購單位Factory
    {
        // ====================== 查詢 ======================
        public List<c訂購單位> queryAll訂購單位()
        {
            List<c訂購單位> list = queryBysql("select * from t訂購單位");
            // 沒找到回傳空值
            if (list.Count == 0)
                return null;
            return list;
        }

        // 指定訂購單位id 回傳訂購單位
        public c訂購單位 query指定訂購單位Id(int fId)
        {
            List<c訂購單位> list = queryBysql($"select * from t訂購單位 where fId = {fId}");
            // 沒找到回傳空值
            if (list.Count == 0)
                return null;
            return list[0];
        }

        // 指定訂購人id 回傳訂購單位
        public c訂購單位 query指定訂購人(int fId)
        {
            c訂購人 p = (new c訂購人Factory()).query訂購人(fId);
            if (p != null)
            {
                List<c訂購單位> list = queryBysql($"select * from t訂購單位 where fId = {p.f訂購單位Id}");
                // 沒找到回傳空值
                if (list.Count == 0)
                    return null;
                return list[0];
            }
            else
            {
                return null;
            }
        }

        public List<c訂購單位> queryBysql(string sql)
        {
            // 1.接水管
            SqlConnection con = new SqlConnection(GlobalVar.sqlstring);
            con.Open();
            // 2.開水龍頭
            SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
            // 3.放水桶
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            con.Close();

            List<c訂購單位> list = new List<c訂購單位>();
            foreach (DataRow r in ds.Tables[0].Rows)
            {
                c訂購單位 x = new c訂購單位();
                x.fId = Convert.ToInt32(r["fId"].ToString());
                x.f訂購單位 = r["f訂購單位"].ToString();
                list.Add(x);
            }
            return list;
        }
    }
}
