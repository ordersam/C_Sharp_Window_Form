﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppBaby
{
    public partial class Form2 : Form
    {
        bool is搜訂購;
        bool is搜餐廳;
        string str搜尋訂購單位;
        string str搜尋訂購人;
        string str搜尋餐廳;
        List<string> list訂購人Now = new List<string>();
        List<ArrayList> list訂購單Now = new List<ArrayList>();

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            reset訂單列表();
        }

        void reset訂單列表()
        {
            // 清空暫存
            lbox訂單列表.Items.Clear();
            lbl總計.Text = "";
            // 搜尋
            is搜訂購 = false;
            is搜餐廳 = false;
            str搜尋訂購單位 = "";
            str搜尋訂購人 = "";
            str搜尋餐廳 = "";
            list訂購人Now.Clear();
            list訂購單Now.Clear();
            cbox訂購單位.Items.Clear();
            cbox訂購人.Items.Clear();
            cbox餐廳.Items.Clear();
            cbox訂購單位.Text = "";
            cbox訂購人.Text = "";
            cbox餐廳.Text = "";
            // 條件
            GlobalOrder.listGlobal訂單所有餐廳.Clear();
            GlobalOrder.listGlobal訂單所有訂購單位.Clear();
            GlobalOrder.dictGlobal訂單所有訂購人.Clear();
            // 可操作
            cbox餐廳.Enabled = true;
            cbox訂購單位.Enabled = true;
            cbox訂購人.Enabled = true;
            // 可排序
            btn排序.Visible = true;

            // 重載無搜尋
            // 檢查有無訂購單
            if (GlobalOrder.listGlobal訂購單.Count > 0)
            {
                foreach (ArrayList my訂購品項 in GlobalOrder.listGlobal訂購單)
                {
                    string str訂購單位 = (string)my訂購品項[0];
                    string str訂購人 = (string)my訂購品項[1];
                    string str餐廳 = (string)my訂購品項[2];
                    string str餐點 = (string)my訂購品項[3];
                    int int數量 = (int)my訂購品項[4];
                    int int單價 = (int)my訂購品項[5];

                    string str訂購品項資訊 = string.Format($"{str訂購單位} {str訂購人}：{str餐廳} {str餐點} {int數量}份 單價 {int單價} 元");
                    lbox訂單列表.Items.Add(str訂購品項資訊);
                }

                // 計算總價
                total計算訂單總價();

                find訂單所有餐廳();
                find訂單所有訂購單位();
                find訂單所有訂購人();
            }
        }

        // 計算總價：更新labal + 回傳總價
        int total計算訂單總價()
        {
            int int總價 = 0;
            foreach (ArrayList my訂購品項 in GlobalOrder.listGlobal訂購單)
            {
                int總價 += (int)my訂購品項[4] * (int)my訂購品項[5];
            }
            lbl總計.Text = int總價.ToString() + " 元";
            return int總價;
        }
        // 篩選條件 計算總價
        int total計算篩選訂單總價()
        {
            int int總價 = 0;
            foreach (ArrayList my訂購品項 in list訂購單Now)
            {
                int總價 += (int)my訂購品項[4] * (int)my訂購品項[5];
            }
            lbl總計.Text = int總價.ToString() + " 元";
            return int總價;
        }

        private void lbox訂單列表_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn排序_Click(object sender, EventArgs e)
        {
            lbox訂單列表.Items.Clear();
            if (GlobalOrder.listGlobal訂購單.Count > 0)
            {
                List<ArrayList> listTemp訂購單 = new List<ArrayList>();
                foreach (string store in GlobalOrder.listGlobal訂單所有餐廳)
                {
                    foreach (ArrayList my訂購品項 in GlobalOrder.listGlobal訂購單)
                    {
                        string str訂購單位 = (string)my訂購品項[0];
                        string str訂購人 = (string)my訂購品項[1];
                        string str餐廳 = (string)my訂購品項[2];
                        string str餐點 = (string)my訂購品項[3];
                        int int數量 = (int)my訂購品項[4];
                        int int單價 = (int)my訂購品項[5];

                        if (store == str餐廳)
                        {
                            string str訂購品項資訊 = string.Format($"{str訂購單位} {str訂購人}：{str餐廳} {str餐點} {int數量}份 單價 {int單價} 元");
                            lbox訂單列表.Items.Add(str訂購品項資訊);

                            // 更新Global
                            ArrayList arraylist訂購單資訊 = new ArrayList();
                            arraylist訂購單資訊.Add(str訂購單位);
                            arraylist訂購單資訊.Add(str訂購人);
                            arraylist訂購單資訊.Add(str餐廳);
                            arraylist訂購單資訊.Add(str餐點);
                            arraylist訂購單資訊.Add(int數量);
                            arraylist訂購單資訊.Add(int單價);
                            listTemp訂購單.Add(arraylist訂購單資訊);
                        }
                    }
                }
                GlobalOrder.listGlobal訂購單 = listTemp訂購單;
            }
        }

        // 訂單所有餐廳
        void find訂單所有餐廳()
        {
            GlobalOrder.listGlobal訂單所有餐廳.Clear();
            cbox餐廳.Items.Clear();
            foreach (ArrayList my訂購品項 in GlobalOrder.listGlobal訂購單)
            {
                string str餐廳 = (string)my訂購品項[2];
                // 訂單所有餐廳
                bool isInside = false;
                foreach (string store in GlobalOrder.listGlobal訂單所有餐廳)
                {
                    if (store == str餐廳)
                    {
                        isInside = true;
                        break;
                    }
                }
                if (!isInside)
                {
                    GlobalOrder.listGlobal訂單所有餐廳.Add(str餐廳);
                    cbox餐廳.Items.Add(str餐廳);
                }
            }
        }

        // 訂單所有訂購單位
        void find訂單所有訂購單位()
        {
            GlobalOrder.listGlobal訂單所有訂購單位.Clear();
            cbox訂購單位.Items.Clear();
            foreach (ArrayList my訂購品項 in GlobalOrder.listGlobal訂購單)
            {
                string str訂購單位 = (string)my訂購品項[0];
                // 訂單所有訂購單位
                bool isInside = false;
                foreach (string org in GlobalOrder.listGlobal訂單所有訂購單位)
                {
                    if (org == str訂購單位)
                    {
                        isInside = true;
                        break;
                    }
                }
                if (!isInside)
                {
                    GlobalOrder.listGlobal訂單所有訂購單位.Add(str訂購單位);
                    cbox訂購單位.Items.Add(str訂購單位);
                }
            }
        }

        // 訂單所有訂購人
        void find訂單所有訂購人()
        {
            GlobalOrder.dictGlobal訂單所有訂購人.Clear();
            cbox訂購人.Items.Clear();

            foreach (string org in GlobalOrder.listGlobal訂單所有訂購單位)
            {
                List<string> person = new List<string>();
                foreach (ArrayList my訂購品項 in GlobalOrder.listGlobal訂購單)
                {
                    string str訂購單位 = (string)my訂購品項[0];
                    string str訂購人 = (string)my訂購品項[1];

                    int index = person.IndexOf(str訂購人);
                    if ( (org == str訂購單位) && (index == -1) )
                    {
                        person.Add(str訂購人);
                    }
                }
                GlobalOrder.dictGlobal訂單所有訂購人.Add(org, person);
            }
        }

        // ======================== 移除、清空 ========================
        // 移除訂單 listbox SelectionMode 改成可多選 MultiExtended
        private void btn移除訂單_Click(object sender, EventArgs e)
        {
            if (lbox訂單列表.SelectedIndices.Count > 0)
            {
                if (is搜訂購)
                {
                    // 移除總表
                    for (int i = lbox訂單列表.SelectedIndices.Count - 1; i >= 0; i--)
                    {
                        GlobalOrder.listGlobal訂購單.RemoveAt((int)list訂購單Now[lbox訂單列表.SelectedIndices[i]][6]);
                    }

                    // 內存 + UI重載
                    if (str搜尋訂購人 == "")
                    {
                        // 清空暫存
                        lbox訂單列表.Items.Clear();
                        list訂購單Now.Clear();
                        // 紀錄在 GlobalOrder.listGlobal訂購單 的index
                        int j = 0;
                        foreach (ArrayList my訂購品項 in GlobalOrder.listGlobal訂購單)
                        {
                            string str訂購單位 = (string)my訂購品項[0];
                            string str訂購人 = (string)my訂購品項[1];
                            string str餐廳 = (string)my訂購品項[2];
                            string str餐點 = (string)my訂購品項[3];
                            int int數量 = (int)my訂購品項[4];
                            int int單價 = (int)my訂購品項[5];

                            if (str搜尋訂購單位 == str訂購單位)
                            {
                                // UI
                                string str訂購品項資訊 = string.Format($"{str訂購單位} {str訂購人}：{str餐廳} {str餐點} {int數量}份 單價 {int單價} 元");
                                lbox訂單列表.Items.Add(str訂購品項資訊);
                                // 內存
                                ArrayList my訂購品項temp = new ArrayList();
                                my訂購品項temp.Add(str訂購單位);
                                my訂購品項temp.Add(str訂購人);
                                my訂購品項temp.Add(str餐廳);
                                my訂購品項temp.Add(str餐點);
                                my訂購品項temp.Add(int數量);
                                my訂購品項temp.Add(int單價);
                                my訂購品項temp.Add(j);
                                list訂購單Now.Add(my訂購品項temp);
                            }
                            j++;
                        }
                    }
                    else
                    {
                        // 清空暫存
                        lbox訂單列表.Items.Clear();
                        list訂購單Now.Clear();
                        // 紀錄在 GlobalOrder.listGlobal訂購單 的index
                        int j = 0;
                        foreach (ArrayList my訂購品項 in GlobalOrder.listGlobal訂購單)
                        {
                            string str訂購單位 = (string)my訂購品項[0];
                            string str訂購人 = (string)my訂購品項[1];
                            string str餐廳 = (string)my訂購品項[2];
                            string str餐點 = (string)my訂購品項[3];
                            int int數量 = (int)my訂購品項[4];
                            int int單價 = (int)my訂購品項[5];

                            if ((str搜尋訂購單位 == str訂購單位) && (str搜尋訂購人 == str訂購人))
                            {
                                // UI
                                string str訂購品項資訊 = string.Format($"{str訂購單位} {str訂購人}：{str餐廳} {str餐點} {int數量}份 單價 {int單價} 元");
                                lbox訂單列表.Items.Add(str訂購品項資訊);
                                // 內存
                                ArrayList my訂購品項temp = new ArrayList();
                                my訂購品項temp.Add(str訂購單位);
                                my訂購品項temp.Add(str訂購人);
                                my訂購品項temp.Add(str餐廳);
                                my訂購品項temp.Add(str餐點);
                                my訂購品項temp.Add(int數量);
                                my訂購品項temp.Add(int單價);
                                my訂購品項temp.Add(j);
                                list訂購單Now.Add(my訂購品項temp);
                            }
                            j++;
                        }
                    }

                    total計算篩選訂單總價();
                }
                else if (is搜餐廳)
                {
                    // 移除總表
                    for (int i = lbox訂單列表.SelectedIndices.Count - 1; i >= 0; i--)
                    {
                        GlobalOrder.listGlobal訂購單.RemoveAt((int)list訂購單Now[lbox訂單列表.SelectedIndices[i]][6]);
                    }

                    // 內存 + UI重載
                    // 清空暫存
                    lbox訂單列表.Items.Clear();
                    list訂購單Now.Clear();
                    // 紀錄在 GlobalOrder.listGlobal訂購單 的index
                    int j = 0;
                    foreach (ArrayList my訂購品項 in GlobalOrder.listGlobal訂購單)
                    {
                        string str訂購單位 = (string)my訂購品項[0];
                        string str訂購人 = (string)my訂購品項[1];
                        string str餐廳 = (string)my訂購品項[2];
                        string str餐點 = (string)my訂購品項[3];
                        int int數量 = (int)my訂購品項[4];
                        int int單價 = (int)my訂購品項[5];

                        if (str搜尋餐廳 == str餐廳)
                        {
                            // UI
                            string str訂購品項資訊 = string.Format($"{str訂購單位} {str訂購人}：{str餐廳} {str餐點} {int數量}份 單價 {int單價} 元");
                            lbox訂單列表.Items.Add(str訂購品項資訊);
                            // 內存
                            ArrayList my訂購品項temp = new ArrayList();
                            my訂購品項temp.Add(str訂購單位);
                            my訂購品項temp.Add(str訂購人);
                            my訂購品項temp.Add(str餐廳);
                            my訂購品項temp.Add(str餐點);
                            my訂購品項temp.Add(int數量);
                            my訂購品項temp.Add(int單價);
                            my訂購品項temp.Add(j);
                            list訂購單Now.Add(my訂購品項temp);
                        }
                        j++;
                    }

                    total計算篩選訂單總價();
                }
                else
                {
                    for (int i = lbox訂單列表.SelectedIndices.Count - 1; i >= 0; i--)
                    {
                        GlobalOrder.listGlobal訂購單.RemoveAt(lbox訂單列表.SelectedIndices[i]);
                        lbox訂單列表.Items.RemoveAt(lbox訂單列表.SelectedIndices[i]);
                    }

                    // 計算總價
                    total計算訂單總價();
                }

                find訂單所有餐廳();
                find訂單所有訂購單位();
                find訂單所有訂購人();
            }
            else
            {
                MessageBox.Show("請選擇訂單！", "移除結果", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btn全部清空_Click(object sender, EventArgs e)
        {
            // 清空後回到無搜尋狀態
            if (is搜訂購 || is搜餐廳)
            {
                // 最後一筆開始 對應總表index 刪除
                for (int i = list訂購單Now.Count - 1; i >= 0; i--)
                {
                    GlobalOrder.listGlobal訂購單.RemoveAt((int)(list訂購單Now[i][6]));
                }

                reset訂單列表();
            }
            else
            {
                GlobalOrder.listGlobal訂購單.Clear();

                // 清空暫存
                lbox訂單列表.Items.Clear();
                lbl總計.Text = "";
                // 搜尋
                is搜訂購 = false;
                is搜餐廳 = false;
                str搜尋訂購單位 = "";
                str搜尋訂購人 = "";
                str搜尋餐廳 = "";
                list訂購人Now.Clear();
                cbox訂購單位.Items.Clear();
                cbox訂購人.Items.Clear();
                cbox餐廳.Items.Clear();
                cbox訂購單位.Text = "";
                cbox訂購人.Text = "";
                cbox餐廳.Text = "";
                // 條件
                GlobalOrder.listGlobal訂單所有餐廳.Clear();
                GlobalOrder.listGlobal訂單所有訂購單位.Clear();
                GlobalOrder.dictGlobal訂單所有訂購人.Clear();

                // 計算總價
                total計算訂單總價();
            }
        }

        // ======================= 搜尋 =======================
        private void cbox訂購單位_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbox訂購單位.SelectedIndex > -1)
            {
                // 正在搜訂購，不可搜餐廳
                is搜訂購 = true;
                is搜餐廳 = false;
                cbox餐廳.Enabled = false;
                str搜尋餐廳 = "";

                // 內存 搜尋訂購單位
                str搜尋訂購單位 = GlobalOrder.listGlobal訂單所有訂購單位[cbox訂購單位.SelectedIndex];
                
                // 訂購人清單 + UI
                list訂購人Now = GlobalOrder.dictGlobal訂單所有訂購人[str搜尋訂購單位];
                cbox訂購人.Items.Clear();
                foreach (string person in list訂購人Now)
                {
                    cbox訂購人.Items.Add(person);
                }
            }
        }

        private void cbox訂購人_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbox訂購人.SelectedIndex > -1)
            {
                str搜尋訂購人 = list訂購人Now[cbox訂購人.SelectedIndex];
            }
        }
        
        private void cbox餐廳_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbox餐廳.SelectedIndex > -1)
            {
                // 正在搜餐廳，不可搜訂購
                is搜訂購 = false;
                is搜餐廳 = true;
                cbox訂購單位.Enabled = false;
                cbox訂購人.Enabled = false;
                str搜尋訂購單位 = "";
                str搜尋訂購人 = "";

                // 內存 搜尋餐廳
                str搜尋餐廳 = GlobalOrder.listGlobal訂單所有餐廳[cbox餐廳.SelectedIndex];
            }
        }
        
        private void btn資料篩選_Click(object sender, EventArgs e)
        {
            if (is搜訂購)
            {
                // 篩選狀態禁止排序
                btn排序.Visible = false;

                if (str搜尋訂購人 == "")
                {
                    // 檢查有無訂購單
                    if (GlobalOrder.listGlobal訂購單.Count > 0)
                    {
                        // 清空暫存
                        lbox訂單列表.Items.Clear();
                        list訂購單Now.Clear();
                        // 紀錄在 GlobalOrder.listGlobal訂購單 的index
                        int i = 0;
                        foreach (ArrayList my訂購品項 in GlobalOrder.listGlobal訂購單)
                        {
                            string str訂購單位 = (string)my訂購品項[0];
                            string str訂購人 = (string)my訂購品項[1];
                            string str餐廳 = (string)my訂購品項[2];
                            string str餐點 = (string)my訂購品項[3];
                            int int數量 = (int)my訂購品項[4];
                            int int單價 = (int)my訂購品項[5];

                            if (str搜尋訂購單位 == str訂購單位)
                            {
                                // UI
                                string str訂購品項資訊 = string.Format($"{str訂購單位} {str訂購人}：{str餐廳} {str餐點} {int數量}份 單價 {int單價} 元");
                                lbox訂單列表.Items.Add(str訂購品項資訊);
                                // 內存
                                ArrayList my訂購品項temp = new ArrayList();
                                my訂購品項temp.Add(str訂購單位);
                                my訂購品項temp.Add(str訂購人);
                                my訂購品項temp.Add(str餐廳);
                                my訂購品項temp.Add(str餐點);
                                my訂購品項temp.Add(int數量);
                                my訂購品項temp.Add(int單價);
                                my訂購品項temp.Add(i);
                                list訂購單Now.Add(my訂購品項temp);
                            }
                            i++;
                        }
                    }
                }
                else
                {
                    // 檢查有無訂購單
                    if (GlobalOrder.listGlobal訂購單.Count > 0)
                    {
                        // 清空暫存
                        lbox訂單列表.Items.Clear();
                        list訂購單Now.Clear();
                        // 紀錄在 GlobalOrder.listGlobal訂購單 的index
                        int i = 0;
                        foreach (ArrayList my訂購品項 in GlobalOrder.listGlobal訂購單)
                        {
                            string str訂購單位 = (string)my訂購品項[0];
                            string str訂購人 = (string)my訂購品項[1];
                            string str餐廳 = (string)my訂購品項[2];
                            string str餐點 = (string)my訂購品項[3];
                            int int數量 = (int)my訂購品項[4];
                            int int單價 = (int)my訂購品項[5];

                            if ((str搜尋訂購單位 == str訂購單位) && (str搜尋訂購人 == str訂購人))
                            {
                                // UI
                                string str訂購品項資訊 = string.Format($"{str訂購單位} {str訂購人}：{str餐廳} {str餐點} {int數量}份 單價 {int單價} 元");
                                lbox訂單列表.Items.Add(str訂購品項資訊);
                                // 內存
                                ArrayList my訂購品項temp = new ArrayList();
                                my訂購品項temp.Add(str訂購單位);
                                my訂購品項temp.Add(str訂購人);
                                my訂購品項temp.Add(str餐廳);
                                my訂購品項temp.Add(str餐點);
                                my訂購品項temp.Add(int數量);
                                my訂購品項temp.Add(int單價);
                                my訂購品項temp.Add(i);
                                list訂購單Now.Add(my訂購品項temp);
                            }
                            i++;
                        }
                    }
                }

                total計算篩選訂單總價();
            }
            else if (is搜餐廳)
            {
                // 篩選狀態禁止排序
                btn排序.Visible = false;

                // 檢查有無訂購單
                if (GlobalOrder.listGlobal訂購單.Count > 0)
                {
                    // 清空暫存
                    lbox訂單列表.Items.Clear();
                    list訂購單Now.Clear();
                    // 紀錄在 GlobalOrder.listGlobal訂購單 的index
                    int i = 0;
                    foreach (ArrayList my訂購品項 in GlobalOrder.listGlobal訂購單)
                    {
                        string str訂購單位 = (string)my訂購品項[0];
                        string str訂購人 = (string)my訂購品項[1];
                        string str餐廳 = (string)my訂購品項[2];
                        string str餐點 = (string)my訂購品項[3];
                        int int數量 = (int)my訂購品項[4];
                        int int單價 = (int)my訂購品項[5];

                        if (str搜尋餐廳 == str餐廳)
                        {
                            // UI
                            string str訂購品項資訊 = string.Format($"{str訂購單位} {str訂購人}：{str餐廳} {str餐點} {int數量}份 單價 {int單價} 元");
                            lbox訂單列表.Items.Add(str訂購品項資訊);
                            // 內存
                            ArrayList my訂購品項temp = new ArrayList();
                            my訂購品項temp.Add(str訂購單位);
                            my訂購品項temp.Add(str訂購人);
                            my訂購品項temp.Add(str餐廳);
                            my訂購品項temp.Add(str餐點);
                            my訂購品項temp.Add(int數量);
                            my訂購品項temp.Add(int單價);
                            my訂購品項temp.Add(i);
                            list訂購單Now.Add(my訂購品項temp);
                        }
                        i++;
                    }
                }

                total計算篩選訂單總價();
            }
            else
            {
                MessageBox.Show("請選擇篩選條件！", "篩選結果", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btn重置篩選_Click(object sender, EventArgs e)
        {
            reset訂單列表();
        }

        // ======================= 另存 =======================
        private void btn另存訂單_Click(object sender, EventArgs e)
        {
            try
            {
                string str完整路徑 = "";
                // 開啟檔案存取器
                SaveFileDialog sfd = new SaveFileDialog();
                // 可以使用的檔名
                sfd.Filter = "Txt File|*.txt";

                // 預設目錄
                //sfd.InitialDirectory = @"C:\Users";
                // 預設檔名
                Random myRnd = new Random();
                int myRndNum = myRnd.Next(1000, 10000);
                string str檔名 = DateTime.Now.ToString("yyyyMMdd_HHmmss_") + myRndNum.ToString() + @"_吃貨訂購單.txt";
                sfd.FileName = str檔名;

                // 檔案存取器 對話框show(使用者沒有選取 就return不繼續存檔動作)
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    str完整路徑 = sfd.FileName;
                }
                else
                {
                    return;
                }

                // 每一行寫成一個list元素
                List<string> lines所有訂單 = new List<string>();
                lines所有訂單.Add("============ Baby點餐機 吃貨訂購單 ============");
                lines所有訂單.Add("訂購時間：" + DateTime.Now.ToString());
                lines所有訂單.Add("=============================================");
                List<string> list指定餐廳所有餐點;
                // 店小計
                int totalEach;
                // 餐小計
                int totalEachMeal;
                int amountEachMeal;
                foreach (string store in GlobalOrder.listGlobal訂單所有餐廳)
                {
                    lines所有訂單.Add($"======== {store} ========");
                    // 店小計
                    totalEach = 0;
                    // 餐點
                    list指定餐廳所有餐點 = find指定餐廳所有餐點(store);
                    foreach (string meal in list指定餐廳所有餐點)
                    {
                        lines所有訂單.Add($"【{meal}】");
                        // 餐小計
                        totalEachMeal = 0;
                        amountEachMeal = 0;
                        foreach (ArrayList my訂購品項 in GlobalOrder.listGlobal訂購單)
                        {
                            string str訂購單位 = (string)my訂購品項[0];
                            string str訂購人 = (string)my訂購品項[1];
                            string str餐廳 = (string)my訂購品項[2];
                            string str餐點 = (string)my訂購品項[3];
                            int int數量 = (int)my訂購品項[4];
                            int int單價 = (int)my訂購品項[5];

                            if ( (str餐廳 == store) && (str餐點 == meal) )
                            {
                                // 店小計
                                totalEach += int數量 * int單價;
                                // 餐小計
                                totalEachMeal += int數量 * int單價;
                                amountEachMeal += int數量;
                                lines所有訂單.Add($"{str訂購單位} {str訂購人}：訂購 {int單價}元 x {int數量}個");
                            }
                        }
                        lines所有訂單.Add($"【餐小計：{amountEachMeal}個 {totalEachMeal} 元】");
                        lines所有訂單.Add($"----------------------");
                    }
                    lines所有訂單.Add($"===== 店小計：{totalEach} 元 =====");
                }
                lines所有訂單.Add("=============================================");
                lines所有訂單.Add("總價：" + total計算訂單總價().ToString() + " 元");

                // 寫入品項檔案
                System.IO.File.WriteAllLines(str完整路徑, lines所有訂單, Encoding.UTF8);
                MessageBox.Show("另存訂單成功！", "另存訂單結果", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception error)
            {
                MessageBox.Show("另存訂單失敗：" + Convert.ToString(error), "另存訂單結果");
            }

            List<string> find指定餐廳所有餐點(string store)
            {
                List<string> menu = new List<string>();
                foreach (ArrayList my訂購品項 in GlobalOrder.listGlobal訂購單)
                {
                    string str訂購單位 = (string)my訂購品項[0];
                    string str訂購人 = (string)my訂購品項[1];
                    string str餐廳 = (string)my訂購品項[2];
                    string str餐點 = (string)my訂購品項[3];
                    int int數量 = (int)my訂購品項[4];
                    int int單價 = (int)my訂購品項[5];

                    if ( (store == str餐廳) && (menu.IndexOf(str餐點) == -1) )
                    {
                        menu.Add(str餐點);
                    }
                }
                return menu;
            }
        }
    }
}
