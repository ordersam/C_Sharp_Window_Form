﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsAppBaby
{
    class GlobalOrder
    {
        // 所有訂購單位
        public static List<string> listGlobalOrg = new List<string>();
        //// 所有訂購人
        //public static List<ArrayList> listGlobalID = new List<ArrayList>();
        //// 所有分類
        //public static List<string> listGlobalClass = new List<string>();
        //// 所有餐廳
        //public static List<ArrayList> listGlobalStore = new List<ArrayList>();

        // 每筆訂購單
        public static List<ArrayList> listGlobal訂購單 = new List<ArrayList>();

        // 訂單所有餐廳
        public static List<string> listGlobal訂單所有餐廳 = new List<string>();
        // 訂單所有訂購單位
        public static List<string> listGlobal訂單所有訂購單位 = new List<string>();
        // 訂單所有訂購人：key訂購單位: Value訂購人
        public static Dictionary<string, List<string>> dictGlobal訂單所有訂購人 = new Dictionary<string, List<string>>();
    }
}
