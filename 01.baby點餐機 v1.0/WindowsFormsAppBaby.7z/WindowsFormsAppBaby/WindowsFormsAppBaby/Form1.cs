﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppBaby
{
    public partial class Form1 : Form
    {
        // =================== setting x file read ===================
        // 訂購單位
        List<string> listOrg = new List<string>();
        void read讀取訂購單位()
        {
            // 清空暫存
            listOrg.Clear();
            cbox訂購單位.Items.Clear();
            // 讀檔
            string str訂購單位檔案 = @"data/class.txt";
            string[] lines所有單位 = System.IO.File.ReadAllLines(str訂購單位檔案);
            // 加入內存
            foreach (string line所有單位 in lines所有單位)
            {
                if (line所有單位 != "")
                {
                    string[] array單位 = line所有單位.Split('|');
                    listOrg.AddRange(array單位);
                }
            }
            // 顯示在UI
            foreach (string item in listOrg)
            {
                cbox訂購單位.Items.Add(item);
            }
            // 記錄在Glabal
            GlobalOrder.listGlobalOrg = listOrg;
        }
        string strOrgNow;

        // 訂購人
        List<ArrayList> listID = new List<ArrayList>();
        void read訂購人()
        {
            // 清空暫存
            listID.Clear();

            // 讀檔
            string str訂購人檔案 = @"data/role.txt";
            string[] lines所有訂購人 = System.IO.File.ReadAllLines(str訂購人檔案);
            // 加入內存
            foreach (string line訂購人 in lines所有訂購人)
            {
                if (line訂購人 != "")
                {
                    string[] array訂購人 = line訂購人.Split('|');

                    ArrayList arraylist訂購人= new ArrayList();
                    arraylist訂購人.Add(Convert.ToInt32(array訂購人[0]));  // 組織代號(1-4)-第一個為0號管理員
                    arraylist訂購人.Add(array訂購人[1]);                   // 訂購人

                    listID.Add(arraylist訂購人);
                }
            }
            //// 記錄在Glabal
            //GlobalOrder.listGlobalID = listID;
        }
        // 對應目前訂購單位的訂購人
        List<string> listIDSelect = new List<string>();
        string strIDNow;

        // 分類
        List<string> listClass = new List<string>() { "飯食", "麵食", "雜食" };
        void listview顯示分類()
        {
            // 圖檔加入imageList1
            string str圖檔路徑 = @"category/";
            string str圖檔名稱 = "";
            for (int i = 0; i < listClass.Count; i++)
            {
                str圖檔名稱 = (i + 1).ToString() + @".png";
                imageList1.Images.Add(Image.FromFile(str圖檔路徑 + str圖檔名稱));
            }

            // 清空暫存
            listView1.Clear();
            // 設定ListView
            listView1.View = View.LargeIcon;
            imageList1.ImageSize = new Size(95, 95);
            listView1.LargeImageList = imageList1;
            // loop 依序新增 ListView元素
            for (int i = 0; i < imageList1.Images.Count; i++)
            {
                ListViewItem item = new ListViewItem();
                item.ImageIndex = i;
                item.Font = new Font("微軟正黑體", 14, FontStyle.Bold);
                item.Text = listClass[i];
                //item.Tag = i;
                listView1.Items.Add(item);
            }

            //// 記錄在Glabal
            //GlobalOrder.listGlobalClass = listClass;
        }
        // user選取分類
        int intClassIndexNow;

        // 餐廳
        List<ArrayList> listStore = new List<ArrayList>();
        void read預設餐廳()
        {
            // 清空暫存
            listStore.Clear();
            // 讀檔
            string str餐廳檔案 = @"data/20201005store.txt";
            string[] lines所有餐廳 = System.IO.File.ReadAllLines(str餐廳檔案);
            // 加入內存
            foreach (string line一家餐廳 in lines所有餐廳)
            {
                if (line一家餐廳 != "")
                {
                    string[] array一家餐廳 = line一家餐廳.Split('|');
                    
                    ArrayList arraylist一家餐廳 = new ArrayList();
                    arraylist一家餐廳.Add(array一家餐廳[0]);     // 餐廳名稱 
                    arraylist一家餐廳.Add(array一家餐廳[1][0]);  // 是否飯食(char)
                    arraylist一家餐廳.Add(array一家餐廳[1][1]);  // 是否麵食(char)
                    arraylist一家餐廳.Add(array一家餐廳[1][2]);  // 是否雜食(char)

                    listStore.Add(arraylist一家餐廳);
                }
            }
            //// 記錄在Glabal
            //GlobalOrder.listGlobalStore = listStore;
        }
        // 分類對應的餐廳
        List<string> listStoreSelect = new List<string>();
        // user選取餐廳
        string strStoreSelect;

        // 菜單
        List<ArrayList> listMenu = new List<ArrayList>();
        string str圖檔路徑 = @"menu/";
        void read預設菜單()
        {
            // 清空暫存
            listMenu.Clear();

            // 讀檔
            string str菜單檔案 = @"data/20201005menu.txt";
            string[] lines所有菜單 = System.IO.File.ReadAllLines(str菜單檔案);
            // 加入內存
            int int菜單單價 = 0;
            foreach (string line所有菜單 in lines所有菜單)
            {
                if (line所有菜單 != "")
                {
                    string[] array菜單 = line所有菜單.Split('|');

                    ArrayList arraylist菜單資訊 = new ArrayList();
                    arraylist菜單資訊.Add(Convert.ToInt32(array菜單[0]));     // 分類(0飯食 1麵食 2雜食)
                    arraylist菜單資訊.Add(array菜單[1]);                      // 餐點
                    arraylist菜單資訊.Add(array菜單[2]);                      // 餐廳
                    bool isInt = int.TryParse(array菜單[3], out int菜單單價);
                    arraylist菜單資訊.Add(int菜單單價);                        // 單價
                    arraylist菜單資訊.Add(array菜單[4]);                      // 圖檔名稱

                    listMenu.Add(arraylist菜單資訊);
                }
            }
        }
        // 分類 + 餐廳 對應的菜單
        List<ArrayList> listMenuSelect = new List<ArrayList>();
        // user選取餐點
        string str餐點;
        int int單價;
        string str圖檔名稱;
        // user選取數量
        int int數量;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            read讀取訂購單位();
            cbox訂購單位.SelectedIndex = 0;
            strOrgNow = listOrg[cbox訂購單位.SelectedIndex];

            read訂購人();
            listIDSelect.Clear();
            cbox訂購人.Items.Clear();
            // 顯示在UI
            foreach (ArrayList item in listID)
            {
                if ( ((int)item[0] == (cbox訂購單位.SelectedIndex + 1)) || ((int)item[0] == 0) )
                {
                    listIDSelect.Add((string)item[1]);
                    cbox訂購人.Items.Add((string)item[1]);
                }
            }
            // 預設是管理員
            cbox訂購人.SelectedIndex = 0;
            strIDNow = listIDSelect[cbox訂購人.SelectedIndex];

            // 內存初始化
            strStoreSelect = "";
            str餐點 = "";
            int單價 = 0;
            str圖檔名稱 = "";
            int數量 = 1;

            // UI初始化
            lbox菜單.Items.Clear();
            nud數量.Value = 1;
            txt單價.Text = "";
            txt小計.Text = "";
            txt系統訊息.Text = "歡迎使用Baby吃貨系統";

            listview顯示分類();
            read預設餐廳();
            read預設菜單();
        }

        // ======================= Event =======================
        // 訂購單位
        private void cbox訂購單位_SelectedIndexChanged(object sender, EventArgs e)
        {
            strOrgNow = listOrg[cbox訂購單位.SelectedIndex];
            // 依照訂購單位改變訂購人
            listIDSelect.Clear();
            cbox訂購人.Items.Clear();
            // 顯示在UI
            foreach (ArrayList item in listID)
            {
                if (((int)item[0] == (cbox訂購單位.SelectedIndex + 1)) || ((int)item[0] == 0))
                {
                    listIDSelect.Add((string)item[1]);
                    cbox訂購人.Items.Add((string)item[1]);
                }
            }
            // 預設是管理員
            if (cbox訂購人.Items.Count > 0)
            {
                cbox訂購人.SelectedIndex = 0;
                strIDNow = listIDSelect[cbox訂購人.SelectedIndex];
            }
        }
        
        // 訂購人
        private void cbox訂購人_SelectedIndexChanged(object sender, EventArgs e)
        {
            strIDNow = listIDSelect[cbox訂購人.SelectedIndex];
        }

        // 點選種類
        private void listView1_ItemActivate(object sender, EventArgs e)
        {
            // user選取分類
            intClassIndexNow = listView1.SelectedIndices[0];

            // 對應目前餐廳
            listStoreSelect.Clear();
            cbox餐廳.Items.Clear();
            foreach (ArrayList store in listStore)
            {
                if ((char)store[intClassIndexNow+1] != '0')
                {    
                    listStoreSelect.Add((string)store[0]);
                    cbox餐廳.Items.Add((string)store[0]);
                }
            }
            // 預設第一家
            cbox餐廳.SelectedIndex = 0;
            strStoreSelect = listStoreSelect[0];

            // 預設第一家 對應菜單
            listMenuSelect.Clear();
            lbox菜單.Items.Clear();
            foreach (ArrayList obj菜單 in listMenu)
            {
                // 分類 + 餐廳 相符
                if ((intClassIndexNow == (int)obj菜單[0]) && (listStoreSelect[cbox餐廳.SelectedIndex] == (string)obj菜單[2]))
                {
                    listMenuSelect.Add(obj菜單);
                    lbox菜單.Items.Add((string)obj菜單[1]);
                }
            }

            // 初始化
            str餐點 = "";
            int單價 = 0;
            str圖檔名稱 = "";
            int數量 = 1;
            nud數量.Value = 1;
            txt單價.Text = "";
            txt小計.Text = "";
            txt系統訊息.Text = "歡迎使用Baby吃貨系統";
        }

        // 點選餐廳
        private void cbox餐廳_SelectedIndexChanged(object sender, EventArgs e)
        {
            // user選取餐廳
            strStoreSelect = listStoreSelect[cbox餐廳.SelectedIndex];

            // 對應菜單
            listMenuSelect.Clear();
            lbox菜單.Items.Clear();
            foreach (ArrayList obj菜單 in listMenu)
            {
                if ((intClassIndexNow == (int)obj菜單[0]) && (listStoreSelect[cbox餐廳.SelectedIndex] == (string)obj菜單[2]))
                {
                    listMenuSelect.Add(obj菜單);
                    lbox菜單.Items.Add((string)obj菜單[1]);
                }
            }

            // 初始化
            str餐點 = "";
            int單價 = 0;
            str圖檔名稱 = "";
            int數量 = 1;
            nud數量.Value = 1;
            txt單價.Text = "";
            txt小計.Text = "";
            txt系統訊息.Text = "歡迎使用Baby吃貨系統";
        }

        // 點選餐點
        private void lbox菜單_SelectedIndexChanged(object sender, EventArgs e)
        {
            ArrayList arraylist選擇餐點 = listMenuSelect[lbox菜單.SelectedIndex];
            // 內存
            str餐點 = (string)arraylist選擇餐點[1];
            int單價 = (int)arraylist選擇餐點[3];
            str圖檔名稱 = (string)arraylist選擇餐點[4];
            // UI
            txt單價.Text = int單價.ToString();
            total計算總價();
            pbox餐點圖.Image = Image.FromFile(str圖檔路徑 + str圖檔名稱);

            txt系統訊息.Text = "歡迎使用Baby吃貨系統";
        }

        // 點選數量
        private void nud數量_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                int數量 = Convert.ToInt32(nud數量.Value);
                txt系統訊息.Text = "歡迎使用Baby吃貨系統";
            }
            catch (Exception error)
            {
                int數量 = 1;
                nud數量.Value = 1;
                txt系統訊息.Text = "數量輸入錯誤 請不要亂玩>w<";
            }
            total計算總價();
        }

        int total計算總價()
        {
            txt小計.Text = (int單價 * int數量).ToString();
            return int單價 * int數量;
        }

        // ======================= Navigator =======================
        private void pbox加入訂購單_Click(object sender, EventArgs e)
        {
            if (lbox菜單.SelectedIndex > -1)
            {
                ArrayList arraylist訂購單資訊 = new ArrayList();

                arraylist訂購單資訊.Add(strOrgNow);
                arraylist訂購單資訊.Add(strIDNow);
                arraylist訂購單資訊.Add(strStoreSelect);
                arraylist訂購單資訊.Add(str餐點);
                arraylist訂購單資訊.Add(int數量);
                arraylist訂購單資訊.Add(int單價);

                GlobalOrder.listGlobal訂購單.Add(arraylist訂購單資訊);
                txt系統訊息.Text = "訂購成功 開啟吃貨之路！";
            }
            else
            {
                txt系統訊息.Text = "訂購失敗 請選擇餐點！";
            }
        }

        private void pbox查看訂購單_Click(object sender, EventArgs e)
        {
            Form form訂單列表 = new Form2();
            form訂單列表.ShowDialog();
        }

        // ======================= read file =======================
        private void pbox讀檔_Click(object sender, EventArgs e)
        {
            // ===================== 餐廳檔 =====================
            MessageBox.Show("請先選擇餐廳檔案！", "餐廳檔");
            OpenFileDialog ofd = new OpenFileDialog();
            // 可以使用的檔名
            ofd.Filter = "Txt File|*.txt|Dat File|*.dat";
            // 預設目錄
            ofd.InitialDirectory = @"C:\Users";
            // 檔案選取器 對話框show
            string str完整路徑;
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                str完整路徑 = ofd.FileName;
            }
            else
            {
                return;
            }

            try
            {
                // 清空暫存
                listStore.Clear();

                string[] lines所有餐廳 = System.IO.File.ReadAllLines(str完整路徑);
                // 加入內存
                int int檢查數字;
                foreach (string line一家餐廳 in lines所有餐廳)
                {
                    if (line一家餐廳 != "")
                    {
                        string[] array一家餐廳 = line一家餐廳.Split('|');

                        // 先檢查第一個字非數字
                        bool isInt = int.TryParse(array一家餐廳[0], out int檢查數字);
                        if (isInt)
                        {
                            read預設餐廳();
                            txt系統訊息.Text = "讀取餐廳檔錯誤 請選擇正確檔案！";
                            return;
                        }

                        ArrayList arraylist一家餐廳 = new ArrayList();
                        arraylist一家餐廳.Add(array一家餐廳[0]);     // 餐廳名稱
                        arraylist一家餐廳.Add(array一家餐廳[1][0]);  // 是否飯食(char)
                        arraylist一家餐廳.Add(array一家餐廳[1][1]);  // 是否麵食(char)
                        arraylist一家餐廳.Add(array一家餐廳[1][2]);  // 是否雜食(char)

                        listStore.Add(arraylist一家餐廳);
                    }
                }
                //// 記錄在Glabal
                //GlobalOrder.listGlobalStore = listStore;
            }
            catch (Exception error)
            {
                read預設餐廳();
                txt系統訊息.Text = "讀取餐廳檔錯誤 請選擇正確檔案！";
                return;
            }

            // ===================== 菜單檔 =====================
            MessageBox.Show("請再選擇菜單檔案！", "菜單檔");
            OpenFileDialog ofd2 = new OpenFileDialog();
            // 可以使用的檔名
            ofd2.Filter = "Txt File|*.txt|Dat File|*.dat";
            // 預設目錄
            ofd2.InitialDirectory = @"C:\Users";
            // 檔案選取器 對話框show
            string str完整路徑2;
            if (ofd2.ShowDialog() == DialogResult.OK)
            {
                str完整路徑2 = ofd2.FileName;
            }
            else
            {
                read預設餐廳();
                txt系統訊息.Text = "讀取菜單檔錯誤 請選擇正確檔案！";
                return;
            }

            try
            {
                // 清空暫存
                listMenu.Clear();
                string[] lines所有菜單 = System.IO.File.ReadAllLines(str完整路徑2);
                // 加入內存
                int int菜單單價 = 0;
                foreach (string line所有菜單 in lines所有菜單)
                {
                    if (line所有菜單 != "")
                    {
                        string[] array菜單 = line所有菜單.Split('|');

                        ArrayList arraylist菜單資訊 = new ArrayList();
                        arraylist菜單資訊.Add(Convert.ToInt32(array菜單[0]));  // 分類(0飯食 1麵食 2雜食)
                        arraylist菜單資訊.Add(array菜單[1]);                   // 餐點
                        arraylist菜單資訊.Add(array菜單[2]);                   // 餐廳
                        bool isInt = int.TryParse(array菜單[3], out int菜單單價);
                        arraylist菜單資訊.Add(int菜單單價);                        // 單價
                        arraylist菜單資訊.Add(array菜單[4]);                   // 圖檔名稱

                        listMenu.Add(arraylist菜單資訊);
                    }
                }

                // 內存初始化
                intClassIndexNow = 0;
                strStoreSelect = "";
                str餐點 = "";
                int單價 = 0;
                str圖檔名稱 = "";
                int數量 = 1;

                // UI初始化
                cbox餐廳.Items.Clear();
                lbox菜單.Items.Clear();
                nud數量.Value = 1;
                txt單價.Text = "";
                txt小計.Text = "";

                txt系統訊息.Text = "讀取檔案成功 普天同慶！";
            }
            catch (Exception error)
            {

                read預設餐廳();
                read預設菜單();
                txt系統訊息.Text = "讀取菜單檔錯誤 請選擇正確檔案！";
            }
        }

        // ===================== change login =====================
        private void pbox登入_Click(object sender, EventArgs e)
        {

        }


    }
}
